# DESECHO setup notes

## Server requirements

- Paper 26.2
- Java 25
- Plasmo Voice server plugin compatible with the target Minecraft/Paper release
- FFmpeg available on PATH, or set `ffmpeg-path` in `plugins/DESECHO/config.yml`
- Put local MP4 files in `plugins/DESECHO/media/`

DESECHO declares `depend: [PlasmoVoice]`; the Plasmo Voice server plugin is required for this source configuration to load. `require-audio: true` makes playback refuse to start when the audio backend is unavailable.

## Every player who should hear audio

- A client for Minecraft 26.2
- The matching Plasmo Voice client mod (Fabric/NeoForge as appropriate)
- An active connection to the server's Plasmo Voice service

A player without the Plasmo Voice client mod may still receive map video, but will not hear the shared audio stream.

## Declared dependency coordinates

- `io.papermc.paper:paper-api:26.2.build.135-stable`
- `su.plo.voice.api:server:2.1.16`

The versions are declared in `gradle.properties`. The API documentation has been reviewed for these targets, but the plugin has not been compiled against the dependency artifacts in this workspace.

## First server test

1. Start Paper with Plasmo Voice installed and verify FFmpeg is available.
2. Put an MP4 with an audio track in `plugins/DESECHO/media/`.
3. As an operator, stand facing a flat wall and look at the wall block where the screen's bottom-left corner should be.
4. Run:

```text
/desecho create test 4 3
/desecho play test file:video.mp4
/desecho info test
/desecho pause test
/desecho resume test
/desecho seek test 0:30
/desecho stop test
/desecho remove test
```

5. Join from a second account with Plasmo Voice client installed. Stand within the configured `audio-range` and `view-range` and verify the video and audio independently.

## Config notes

- `audio-range`: maximum distance for Plasmo Voice audio.
- `view-range`: maximum distance for picture updates.
- `require-audio`: when `true`, playback is refused if the voice backend cannot be opened.
- `ffmpeg-path`: executable name or full path to FFmpeg.

**This is still source-only and unverified in-game.** Do not treat the project as ready to install until the local compilation and multiplayer server tests pass.
