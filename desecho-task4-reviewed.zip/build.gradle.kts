allprojects {
    group = "dev.des.desecho"
    version = "0.1.0"
    repositories { mavenCentral() }
}
