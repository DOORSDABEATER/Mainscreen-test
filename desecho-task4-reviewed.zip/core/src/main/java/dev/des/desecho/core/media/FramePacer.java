package dev.des.desecho.core.media;

/** Picks what to show for the clock's current position; stale frames are discarded, never queued up. */
public final class FramePacer {
    public record Pick(Frame frame, int skipped) {}

    private FramePacer() {}

    /** Returns the newest frame whose timestamp is due (<= positionMs); frame is null if none is due yet. Single consumer only. */
    public static Pick pick(FrameQueue q, long positionMs) {
        Frame latest = null;
        int taken = 0;
        Frame f;
        while ((f = q.peek()) != null && f.ptsMs() <= positionMs) {
            latest = q.poll();
            taken++;
        }
        return new Pick(latest, Math.max(0, taken - 1));
    }
}
