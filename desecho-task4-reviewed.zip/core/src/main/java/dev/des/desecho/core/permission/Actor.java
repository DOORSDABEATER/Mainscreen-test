package dev.des.desecho.core.permission;

import java.util.UUID;

/**
 * Who is performing an action. Identity is the UUID only; displayName is for log lines and is
 * never used for any ownership or permission decision (so renames cannot affect ownership).
 * The Bukkit layer builds this from real server-side permission checks
 * (desecho.play / desecho.display.manage / desecho.admin or OP).
 */
public record Actor(UUID id, String displayName, boolean canPlay, boolean canManageDisplays, boolean admin) {
    public static final UUID CONSOLE_ID = new UUID(0L, 0L);

    public static Actor console() {
        return new Actor(CONSOLE_ID, "CONSOLE", true, true, true);
    }
}
