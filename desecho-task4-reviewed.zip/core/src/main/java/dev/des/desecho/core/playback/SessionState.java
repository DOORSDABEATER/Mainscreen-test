package dev.des.desecho.core.playback;

public enum SessionState { RESOLVING, BUFFERING, PLAYING, PAUSED, FAILED }
