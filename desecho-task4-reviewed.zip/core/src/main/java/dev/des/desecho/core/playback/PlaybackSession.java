package dev.des.desecho.core.playback;

import java.util.UUID;

/** State of one playback on one screen. Mutated only through SessionManager (package-private setters). */
public final class PlaybackSession {
    private final UUID sessionId = UUID.randomUUID();
    private final String screenId;
    private final String source;
    private final PlaybackClock clock;
    private final long createdAtMs = System.currentTimeMillis();
    private volatile UUID ownerId;
    private volatile SessionState state = SessionState.RESOLVING;
    private volatile int volume = 100;
    private volatile boolean muted;
    private volatile int seekEpoch;
    private volatile FailureStage failureStage;
    private volatile String failureMessage;

    PlaybackSession(String screenId, UUID ownerId, String source, PlaybackClock clock) {
        this.screenId = screenId;
        this.ownerId = ownerId;
        this.source = source;
        this.clock = clock;
    }

    public UUID sessionId() { return sessionId; }
    public String screenId() { return screenId; }
    public String source() { return source; }
    public UUID ownerId() { return ownerId; }
    public SessionState state() { return state; }
    public int volume() { return volume; }
    public boolean muted() { return muted; }
    public PlaybackClock clock() { return clock; }
    public long createdAtMs() { return createdAtMs; }
    /** Incremented on every seek; decoders/audio feeders restart when they see it change. */
    public int seekEpoch() { return seekEpoch; }
    public FailureStage failureStage() { return failureStage; }
    public String failureMessage() { return failureMessage; }

    void setOwner(UUID o) { ownerId = o; }
    void setState(SessionState s) { state = s; }
    void setVolume(int v) { volume = v; }
    void setMuted(boolean m) { muted = m; }
    void bumpSeekEpoch() { seekEpoch++; }
    void setFailure(FailureStage st, String msg) { failureStage = st; failureMessage = msg; state = SessionState.FAILED; }
}
