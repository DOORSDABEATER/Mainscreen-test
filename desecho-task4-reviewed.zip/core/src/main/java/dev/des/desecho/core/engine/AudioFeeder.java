package dev.des.desecho.core.engine;

import dev.des.desecho.core.media.ErrorSanitizer;
import dev.des.desecho.core.media.FfmpegCommands;
import dev.des.desecho.core.playback.PlaybackSession;
import dev.des.desecho.core.playback.SessionManager;
import dev.des.desecho.core.playback.SessionState;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * Feeds 20 ms PCM frames (48 kHz, mono, s16le = 1920 bytes) to a PcmSink, paced against the SAME
 * session clock the picture uses. Pause stops delivery, seek restarts ffmpeg at the new position,
 * frames that are too late are dropped (never queued). The Plasmo Voice side is just a PcmSink
 * implementation; nothing in here knows about Plasmo Voice.
 */
public final class AudioFeeder implements AutoCloseable {
    public static final int FRAME_MS = 20;
    public static final int FRAME_BYTES = 1920;
    private static final long LEAD_MS = 40;        // send at most this far ahead of the clock
    private static final long MAX_LATE_MS = 200;   // older than this -> drop to catch up
    private static final long START_LEAD_MS = 300; // process start-up allowance

    public interface PcmSink { void accept(byte[] frame); }

    private static final class Proc {
        final Process p;
        final InputStream in;
        final Thread err;
        final StringBuilder tail = new StringBuilder();

        Proc(Process p, String name) {
            this.p = p;
            this.in = p.getInputStream();
            this.err = new Thread(() -> {
                try (var r = new BufferedReader(new InputStreamReader(p.getErrorStream(), StandardCharsets.UTF_8))) {
                    String l;
                    while ((l = r.readLine()) != null) {
                        synchronized (tail) { tail.append(l).append(' '); if (tail.length() > 2000) tail.delete(0, tail.length() - 2000); }
                    }
                } catch (IOException ignored) { }
            }, "desecho-audio-err-" + name);
            err.setDaemon(true);
            err.start();
        }

        String errorText() { synchronized (tail) { return ErrorSanitizer.sanitize(tail.toString()); } }

        void kill() {
            p.destroy();
            try { if (!p.waitFor(2, TimeUnit.SECONDS)) p.destroyForcibly(); }
            catch (InterruptedException e) { p.destroyForcibly(); Thread.currentThread().interrupt(); }
        }
    }

    private final SessionManager mgr;
    private final PlaybackSession session;
    private final FfmpegCommands.Source src;
    private final String ffmpeg;
    private final int maxSeconds;
    private final PcmSink sink;
    private final BooleanSupplier hasListeners;
    private final Consumer<String> onError;
    private final long idleGraceMs;
    private final Thread thread;
    private volatile boolean closed;
    private volatile Proc current;
    private final AtomicLong delivered = new AtomicLong(), dropped = new AtomicLong(), restarts = new AtomicLong();
    private volatile long lastBaseMs;

    public AudioFeeder(SessionManager mgr, PlaybackSession session, FfmpegCommands.Source src, String ffmpeg, int maxSeconds,
                       long idleGraceMs, PcmSink sink, BooleanSupplier hasListeners, Consumer<String> onError) {
        this.mgr = mgr; this.session = session; this.src = src; this.ffmpeg = ffmpeg; this.maxSeconds = maxSeconds;
        this.idleGraceMs = idleGraceMs; this.sink = sink; this.hasListeners = hasListeners; this.onError = onError;
        this.thread = new Thread(this::run, "desecho-audio-" + session.screenId());
        thread.setDaemon(true);
    }

    public void start() { thread.start(); }
    public boolean isRunning() { return thread.isAlive(); }
    public boolean isDecoding() { var c = current; return c != null && c.p.isAlive(); }
    public long delivered() { return delivered.get(); }
    public long dropped() { return dropped.get(); }
    public long restarts() { return restarts.get(); }
    public long lastBaseMs() { return lastBaseMs; }

    private boolean sessionAlive() {
        return !closed && mgr.get(session.screenId()).orElse(null) == session && session.state() != SessionState.FAILED;
    }

    private void run() {
        Proc proc = null;
        try {
            int epoch = session.seekEpoch();
            long baseMs = 0, idx = 0, noListenersSince = -1;
            boolean finished = false, reported = false;
            while (sessionAlive()) {
                SessionState st = session.state();
                if (st == SessionState.RESOLVING || st == SessionState.BUFFERING) { Thread.sleep(10); continue; }
                boolean listeners = hasListeners.getAsBoolean();
                long now = System.nanoTime();
                if (listeners) noListenersSince = -1; else if (noListenersSince < 0) noListenersSince = now;

                if (session.seekEpoch() != epoch) {
                    epoch = session.seekEpoch();
                    if (proc != null) { proc.kill(); proc = null; current = null; }
                    finished = false;
                }
                if (proc != null && !listeners && (now - noListenersSince) / 1_000_000L >= idleGraceMs) {
                    proc.kill(); proc = null; current = null;
                }
                if (proc == null) {
                    if (!listeners || finished) { Thread.sleep(25); continue; }
                    baseMs = session.clock().positionMs() + START_LEAD_MS;
                    lastBaseMs = baseMs;
                    idx = 0;
                    long remaining = Math.max(1, maxSeconds - baseMs / 1000);
                    proc = new Proc(new ProcessBuilder(FfmpegCommands.audio(ffmpeg, src, baseMs, (int) remaining)).start(), session.screenId());
                    proc.p.getOutputStream().close();
                    current = proc;
                    restarts.incrementAndGet();
                }

                byte[] frame = new byte[FRAME_BYTES];
                if (!readFully(proc.in, frame)) {
                    if (closed) break;
                    int code = proc.p.waitFor(2, TimeUnit.SECONDS) ? proc.p.exitValue() : -1;
                    if (code != 0 && !reported) {
                        reported = true;
                        String m = proc.errorText();
                        onError.accept(m.isEmpty() ? "This video has no usable audio." : m);
                    }
                    proc.kill(); proc = null; current = null;
                    finished = true;
                    continue;
                }
                long due = baseMs + idx * FRAME_MS;
                idx++;
                while (!closed) {
                    long pos = session.clock().positionMs();
                    if (due <= pos + LEAD_MS) break;
                    if (session.seekEpoch() != epoch || !sessionAlive()) break;
                    Thread.sleep(Math.min(10, Math.max(1, due - pos - LEAD_MS)));
                }
                if (!sessionAlive() || session.seekEpoch() != epoch) continue;
                if (session.clock().positionMs() - due > MAX_LATE_MS) { dropped.incrementAndGet(); continue; }
                sink.accept(frame);
                delivered.incrementAndGet();
            }
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        } catch (Throwable t) {
            try { onError.accept("The audio pipeline failed unexpectedly."); } catch (Throwable ignored) { }
        } finally {
            if (proc != null) proc.kill();
            current = null;
        }
    }

    private static boolean readFully(InputStream in, byte[] buf) {
        try {
            int off = 0;
            while (off < buf.length) {
                int n = in.read(buf, off, buf.length - off);
                if (n < 0) return false;
                off += n;
            }
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    @Override
    public void close() {
        closed = true;
        var c = current;
        if (c != null) c.kill();
        thread.interrupt();
        try { thread.join(5000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
