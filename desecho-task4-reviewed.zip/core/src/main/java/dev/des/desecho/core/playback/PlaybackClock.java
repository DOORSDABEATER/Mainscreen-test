package dev.des.desecho.core.playback;

import java.util.function.LongSupplier;

/**
 * The single source of truth for "where are we in the video". Video presenters and audio feeders
 * both read this; nothing else keeps its own notion of time. Thread-safe. Speed changes are NOT
 * supported (1.0x only).
 */
public final class PlaybackClock {
    private final LongSupplier nanos;
    private long basePosMs;
    private long baseNanos;
    private boolean running;

    public PlaybackClock(LongSupplier nanos) { this.nanos = nanos; }

    public synchronized void start(long posMs) {
        basePosMs = Math.max(0, posMs);
        baseNanos = nanos.getAsLong();
        running = true;
    }

    public synchronized void pause() {
        if (running) {
            basePosMs = positionMs();
            running = false;
        }
    }

    public synchronized void resume() {
        if (!running) {
            baseNanos = nanos.getAsLong();
            running = true;
        }
    }

    public synchronized void seek(long posMs) {
        basePosMs = Math.max(0, posMs);
        baseNanos = nanos.getAsLong();
    }

    public synchronized long positionMs() {
        return running ? basePosMs + (nanos.getAsLong() - baseNanos) / 1_000_000L : basePosMs;
    }

    public synchronized boolean isRunning() { return running; }
}
