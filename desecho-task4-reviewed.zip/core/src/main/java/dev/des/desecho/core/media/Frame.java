package dev.des.desecho.core.media;

/** One decoded rgb24 frame, stamped with the media timestamp it should be shown at. */
public record Frame(long index, long ptsMs, byte[] rgb) {}
