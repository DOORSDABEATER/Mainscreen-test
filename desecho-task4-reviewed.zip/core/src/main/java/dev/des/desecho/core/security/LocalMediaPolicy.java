package dev.des.desecho.core.security;

import java.io.IOException;
import java.nio.file.InvalidPathException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Local files are only playable if they live under an admin-approved directory. Requests are
 * RELATIVE names; absolute paths, "..", and symlinks that leave the root are all refused. Every
 * failure returns the same generic message so players cannot probe the filesystem.
 * The approved directories must only contain trusted files (ffmpeg sniffs content, not extensions).
 */
public final class LocalMediaPolicy {
    private static final String GENERIC = "That local media file was not found or is not permitted.";
    private final List<Path> roots = new ArrayList<>();
    private final Set<String> extensions;

    public LocalMediaPolicy(List<Path> approvedRoots, Set<String> allowedExtensions) throws IOException {
        for (Path p : approvedRoots) roots.add(p.toRealPath());
        this.extensions = Set.copyOf(allowedExtensions);
    }

    /** @return the real absolute path to hand to the decoder. */
    public Path resolve(String requested) throws SecurityRejection {
        if (requested == null || requested.isBlank()) throw new SecurityRejection(GENERIC);
        Path rel;
        try {
            rel = Path.of(requested.trim());
        } catch (InvalidPathException e) {
            throw new SecurityRejection(GENERIC);
        }
        if (rel.isAbsolute()) throw new SecurityRejection(GENERIC);
        String name = rel.getFileName() == null ? "" : rel.getFileName().toString().toLowerCase(Locale.ROOT);
        int dot = name.lastIndexOf('.');
        if (dot < 0 || !extensions.contains(name.substring(dot + 1))) throw new SecurityRejection(GENERIC);
        for (Path root : roots) {
            Path candidate = root.resolve(rel).normalize();
            if (!candidate.startsWith(root) || !Files.isRegularFile(candidate)) continue;
            try {
                Path real = candidate.toRealPath();
                if (real.startsWith(root)) return real;
            } catch (IOException ignored) {
                // fall through to rejection
            }
        }
        throw new SecurityRejection(GENERIC);
    }
}
