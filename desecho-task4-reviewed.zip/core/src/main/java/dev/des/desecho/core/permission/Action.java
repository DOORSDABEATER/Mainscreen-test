package dev.des.desecho.core.permission;

public enum Action {
    PLAY(Kind.PLAY),
    INFO(Kind.ANYONE),
    STOP(Kind.OWNER), PAUSE(Kind.OWNER), RESUME(Kind.OWNER), SEEK(Kind.OWNER), VOLUME(Kind.OWNER), MUTE(Kind.OWNER),
    FORCE_STOP(Kind.ADMIN), TRANSFER(Kind.ADMIN),
    CREATE_DISPLAY(Kind.DISPLAY_MANAGE), DELETE_DISPLAY(Kind.DISPLAY_MANAGE), CONFIGURE_DISPLAY(Kind.DISPLAY_MANAGE);

    public enum Kind { ANYONE, PLAY, OWNER, DISPLAY_MANAGE, ADMIN }

    public final Kind kind;

    Action(Kind kind) { this.kind = kind; }
}
