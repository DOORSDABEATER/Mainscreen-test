package dev.des.desecho.core.media;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/**
 * Builds ffmpeg argument LISTS (never a shell string; ProcessBuilder runs them directly). User input
 * only ever appears as the single value after -i, preceded by a protocol whitelist.
 */
public final class FfmpegCommands {
    private static final String REMOTE_PROTOCOLS = "http,https,tcp,tls,crypto";

    private FfmpegCommands() {}

    /** target must already be validated: a UrlGuard-approved http(s) URL, or a LocalMediaPolicy real path. */
    public record Source(String target, boolean local) {
        public Source {
            Objects.requireNonNull(target);
            if (local) {
                if (!Path.of(target).isAbsolute()) throw new IllegalArgumentException("local source must be an absolute path");
            } else if (!target.startsWith("http://") && !target.startsWith("https://")) {
                throw new IllegalArgumentException("remote source must be http(s)");
            }
        }
    }

    private static List<String> head(String ffmpeg, Source s, long startMs) {
        List<String> c = new ArrayList<>(List.of(ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-threads", "2"));
        c.add("-protocol_whitelist");
        c.add(s.local() ? "file" : REMOTE_PROTOCOLS);
        if (!s.local()) {
            c.addAll(List.of("-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "5", "-rw_timeout", "15000000"));
        }
        if (startMs > 0) {
            c.add("-ss");
            c.add(String.format(Locale.ROOT, "%d.%03d", startMs / 1000, startMs % 1000));
        }
        c.add("-i");
        c.add(s.target());
        return c;
    }

    /** rgb24 frames of exactly decodeW x decodeH, aspect preserved with black letterbox/pillarbox, at plan.fps. */
    public static List<String> video(String ffmpeg, Source s, long startMs, QualityPreset.CanvasPlan p, int maxSeconds) {
        List<String> c = head(ffmpeg, s, startMs);
        c.addAll(List.of("-t", String.valueOf(maxSeconds), "-an", "-sn", "-dn", "-vf",
                String.format(Locale.ROOT,
                        "fps=%d,scale=%d:%d:flags=fast_bilinear:force_original_aspect_ratio=decrease,pad=%d:%d:(ow-iw)/2:(oh-ih)/2:black",
                        p.fps(), p.decodeW(), p.decodeH(), p.decodeW(), p.decodeH()),
                "-pix_fmt", "rgb24", "-f", "rawvideo", "pipe:1"));
        return c;
    }

    /** 48 kHz mono signed 16-bit little-endian PCM (the format Plasmo Voice sources consume; verified in Phase 3, not yet). */
    public static List<String> audio(String ffmpeg, Source s, long startMs, int maxSeconds) {
        List<String> c = head(ffmpeg, s, startMs);
        c.addAll(List.of("-t", String.valueOf(maxSeconds), "-vn", "-sn", "-dn", "-ac", "1", "-ar", "48000", "-f", "s16le", "pipe:1"));
        return c;
    }
}
