package dev.des.desecho.core.engine;

import dev.des.desecho.core.display.PaletteQuantizer;
import dev.des.desecho.core.media.FfmpegCommands;
import dev.des.desecho.core.media.FfmpegVideoDecoder;
import dev.des.desecho.core.media.Frame;
import dev.des.desecho.core.media.FrameQueue;
import dev.des.desecho.core.media.FramePacer;
import dev.des.desecho.core.media.QualityPreset;
import dev.des.desecho.core.playback.FailureStage;
import dev.des.desecho.core.playback.PlaybackSession;
import dev.des.desecho.core.playback.SessionManager;
import dev.des.desecho.core.playback.SessionState;

import java.io.IOException;
import java.util.function.BooleanSupplier;

/**
 * Drives one session's picture: decoder -> bounded queue -> clock-paced presenter -> display sink.
 * Owns one presenter thread and at most one ffmpeg process. Reacts to the shared session clock:
 * pause freezes the picture, seek restarts the decoder at the new position, viewers leaving stops
 * the decoder (after a grace period) and viewers returning restarts it at the current clock position.
 * hasViewers is called from the presenter thread and must be thread-safe.
 */
public final class ScreenPlayer implements AutoCloseable {
    public record Config(String ffmpeg, int displayW, int displayH, QualityPreset.CanvasPlan plan,
                         int maxSeconds, int queueCapacity, long idleGraceMs) {}

    private final SessionManager mgr;
    private final PlaybackSession session;
    private final FfmpegCommands.Source src;
    private final Config cfg;
    private final PaletteQuantizer quantizer;
    private final DisplaySink sink;
    private final BooleanSupplier hasViewers;
    private final FrameQueue queue;
    private final byte[] canvas;
    private final Thread presenter;

    private volatile boolean closed;
    private volatile FfmpegVideoDecoder decoder;
    private volatile int gen;
    private volatile FfmpegVideoDecoder.End endState;
    private volatile String endMsg = "";
    private volatile long frameCount;
    private long decoderStartMs;
    private boolean eof;

    public ScreenPlayer(SessionManager mgr, PlaybackSession session, FfmpegCommands.Source src, Config cfg,
                        PaletteQuantizer quantizer, DisplaySink sink, BooleanSupplier hasViewers) {
        this.mgr = mgr;
        this.session = session;
        this.src = src;
        this.cfg = cfg;
        this.quantizer = quantizer;
        this.sink = sink;
        this.hasViewers = hasViewers;
        this.queue = new FrameQueue(cfg.queueCapacity());
        this.canvas = new byte[cfg.displayW() * cfg.displayH()];
        this.presenter = new Thread(this::run, "desecho-present-" + session.screenId());
        presenter.setDaemon(true);
    }

    public void start() { presenter.start(); }

    public boolean isRunning() { return presenter.isAlive(); }
    public boolean isDecoding() { var d = decoder; return d != null && d.isAlive(); }
    public long framesPresented() { return frameCount; }

    private void run() {
        try {
            int epoch = session.seekEpoch();
            mgr.markBuffering(session);
            boolean ready = false;
            long noViewersSince = -1;
            long tick = Math.max(5, 1000L / cfg.plan().fps());
            while (!closed) {
                if (mgr.get(session.screenId()).orElse(null) != session || session.state() == SessionState.FAILED) break;

                boolean viewers = hasViewers.getAsBoolean();
                long now = System.nanoTime();
                if (viewers) noViewersSince = -1; else if (noViewersSince < 0) noViewersSince = now;

                if (session.seekEpoch() != epoch) {
                    epoch = session.seekEpoch();
                    stopDecoder(); queue.clear(); eof = false; endState = null;
                }
                if (!viewers && decoder != null && (now - noViewersSince) / 1_000_000L >= cfg.idleGraceMs()) {
                    stopDecoder(); queue.clear(); eof = false; endState = null;
                }
                if (viewers && decoder == null && !eof) {
                    startDecoder(ready ? session.clock().positionMs() : 0);
                    if (closed) break;
                }

                if (!ready && queue.peek() != null) {
                    ready = mgr.markReady(session, decoderStartMs);
                    if (!ready) break;
                }
                SessionState st = session.state();
                if (ready && (st == SessionState.PLAYING || st == SessionState.PAUSED)) {
                    var pick = FramePacer.pick(queue, session.clock().positionMs());
                    Frame f = pick.frame();
                    if (f != null) {
                        quantizer.blit(f.rgb(), cfg.plan().decodeW(), cfg.plan().decodeH(), cfg.plan().upscale(),
                                canvas, cfg.displayW(), cfg.displayH());
                        sink.present(canvas);
                        frameCount++;
                    }
                }

                FfmpegVideoDecoder.End e = endState;
                if (e == FfmpegVideoDecoder.End.ERROR) {
                    mgr.fail(session, FailureStage.DECODING, endMsg);
                    break;
                }
                if (e == FfmpegVideoDecoder.End.EOF) {
                    eof = true;
                    if (queue.size() == 0) {
                        if (ready) mgr.end(session);
                        else mgr.fail(session, FailureStage.DECODING, "The video contained no frames.");
                        break;
                    }
                }
                Thread.sleep(tick);
            }
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        } catch (Throwable t) {
            mgr.fail(session, FailureStage.DISPLAY, "The display failed unexpectedly.");
        } finally {
            stopDecoder();
            try { sink.clear(); } catch (Throwable ignored) { }
        }
    }

    private void startDecoder(long posMs) {
        int g = ++gen;
        endState = null;
        endMsg = "";
        long remaining = Math.max(1, cfg.maxSeconds() - posMs / 1000);
        var cmd = FfmpegCommands.video(cfg.ffmpeg(), src, posMs, cfg.plan(), (int) remaining);
        try {
            decoder = FfmpegVideoDecoder.start(session.screenId() + "-" + g, cmd, cfg.plan().decodeW(), cfg.plan().decodeH(),
                    cfg.plan().fps(), posMs, queue, false, (end, msg) -> {
                        if (g == gen) { endMsg = msg; endState = end; }
                    });
            decoderStartMs = posMs;
        } catch (IOException ex) {
            mgr.fail(session, FailureStage.DECODING, "The video decoder could not be started.");
            closed = true;
        }
    }

    private void stopDecoder() {
        var d = decoder;
        decoder = null;
        gen++;
        if (d != null) d.close();
    }

    /** Idempotent. Safe to call after the session was stopped. */
    @Override
    public void close() {
        closed = true;
        presenter.interrupt();
        try { presenter.join(5000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
