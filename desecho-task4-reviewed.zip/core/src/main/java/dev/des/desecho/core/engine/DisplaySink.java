package dev.des.desecho.core.engine;

/**
 * Where finished frames go. The Paper layer implements this (diff against the last canvas, push map
 * updates to viewers). present() is called on the presenter thread, NOT the server thread, and the
 * array is reused: copy it or finish with it before returning.
 */
public interface DisplaySink {
    void present(byte[] canvasIndices);
    void clear();
}
