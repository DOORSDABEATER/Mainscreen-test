package dev.des.desecho.core.permission;

import java.util.UUID;

/** Single place where "who may do what" is decided. Pure function, no server dependencies. */
public final class AccessPolicy {
    private AccessPolicy() {}

    public record Decision(boolean allowed, String reason) {
        static Decision yes() { return new Decision(true, ""); }
        static Decision no(String why) { return new Decision(false, why); }
    }

    /** @param owner the session owner's UUID, or null when the action has no session (e.g. PLAY). */
    public static Decision check(Actor actor, Action action, UUID owner) {
        if (actor.admin()) return Decision.yes();
        switch (action.kind) {
            case ANYONE:
                return Decision.yes();
            case PLAY:
                return actor.canPlay() ? Decision.yes()
                        : Decision.no("You don't have permission to start playback.");
            case OWNER:
                return owner != null && owner.equals(actor.id()) ? Decision.yes()
                        : Decision.no("Only the person who started this playback (or an admin) can do that.");
            case DISPLAY_MANAGE:
                return actor.canManageDisplays() ? Decision.yes()
                        : Decision.no("You don't have permission to manage displays.");
            default:
                return Decision.no("Administrators only.");
        }
    }
}
