package dev.des.desecho.core.display;

/**
 * Pure screen geometry (no Bukkit). Coordinates are Minecraft world axes: x = east, y = up, z = south.
 *
 * Conventions (same as Screen.java / README):
 *  - (nx, nz) is the horizontal unit normal the screen FACES = BlockFace#getModX/getModZ of the clicked face
 *    (NORTH = (0,-1), SOUTH = (0,1), EAST = (1,0), WEST = (-1,0)). The wall is behind the screen, in direction -n.
 *  - "right" is the viewer's right while looking at the screen (looking along -n): right = (nz, 0, -nx).
 *  - The anchor is the AIR block in front of the wall at the screen's BOTTOM-LEFT as seen by the viewer.
 *  - Cell (row, col): row 0 = TOP, col 0 = LEFT. Cell block = anchor + right*col + up*(rows-1-row).
 */
public final class ScreenGeometry {
    private ScreenGeometry() { }

    /** Distance of the map surface from the wall plane (item frame thickness, 1/16 block). Cosmetic for audio only. */
    public static final double SURFACE_FROM_WALL = 1.0 / 16.0;

    public static int rightX(int nx, int nz) { return nz; }
    public static int rightZ(int nx, int nz) { return -nx; }

    /** Block offset of cell (row, col) from the anchor block: {dx, dy, dz}. */
    public static int[] cellOffset(int nx, int nz, int rows, int row, int col) {
        return new int[]{rightX(nx, nz) * col, rows - 1 - row, rightZ(nx, nz) * col};
    }

    /**
     * Physical centre of the screen surface, as {x, y, z} OFFSET from the anchor block's minimum corner
     * (add anchor.getX()/getY()/getZ()). Horizontal and vertical centre are the middle of the whole cols x rows
     * rectangle; depth is the map surface (wall plane + 1/16 block), not the middle of the air block.
     */
    public static double[] center(int nx, int nz, int cols, int rows) {
        double h = (cols - 1) / 2.0;
        double inset = 0.5 - SURFACE_FROM_WALL;       // from block centre towards the wall
        double x = 0.5 + rightX(nx, nz) * h - nx * inset;
        double z = 0.5 + rightZ(nx, nz) * h - nz * inset;
        return new double[]{x, rows / 2.0, z};
    }
}
