package dev.des.desecho.core;

import dev.des.desecho.core.display.ScreenGeometry;

/** Geometry checks for Screen placement/centre. Independent oracle: hard-coded physical "right" per facing + brute-force bounding box. */
final class GeometryChecks {
    private GeometryChecks() { }

    // facing name, nx, nz, physical right of a viewer looking at the wall (viewer stands on the facing side)
    private static final Object[][] FACES = {
            {"NORTH", 0, -1, -1, 0},   // viewer north of wall looks south -> right = west (-x)
            {"SOUTH", 0, 1, 1, 0},     // looks north -> right = east (+x)
            {"EAST", 1, 0, 0, -1},     // looks west  -> right = north (-z)
            {"WEST", -1, 0, 0, 1},     // looks east  -> right = south (+z)
    };
    private static final int[][] SIZES = {{1, 1}, {2, 2}, {3, 3}, {4, 3}, {5, 4}};
    private static final double EPS = 1e-9;

    static void run() {
        for (Object[] f : FACES) {
            String nm = (String) f[0]; int nx = (int) f[1], nz = (int) f[2], erx = (int) f[3], erz = (int) f[4];
            TestMain.check("geometry " + nm + ": right vector matches physical right",
                    ScreenGeometry.rightX(nx, nz) == erx && ScreenGeometry.rightZ(nx, nz) == erz);
            for (int[] s : SIZES) {
                int cols = s[0], rows = s[1];
                String tag = "geometry " + nm + " " + cols + "x" + rows;
                int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
                int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
                boolean adjacent = true, distinct = true;
                java.util.Set<String> seen = new java.util.HashSet<>();
                for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++) {
                    int[] o = ScreenGeometry.cellOffset(nx, nz, rows, r, c);
                    distinct &= seen.add(o[0] + "," + o[1] + "," + o[2]);
                    minX = Math.min(minX, o[0]); maxX = Math.max(maxX, o[0] + 1);
                    minY = Math.min(minY, o[1]); maxY = Math.max(maxY, o[1] + 1);
                    minZ = Math.min(minZ, o[2]); maxZ = Math.max(maxZ, o[2] + 1);
                    if (c + 1 < cols) {
                        int[] n = ScreenGeometry.cellOffset(nx, nz, rows, r, c + 1);
                        adjacent &= n[0] - o[0] == erx && n[1] == o[1] && n[2] - o[2] == erz;   // next column = viewer's right
                    }
                    if (r + 1 < rows) {
                        int[] n = ScreenGeometry.cellOffset(nx, nz, rows, r + 1, c);
                        adjacent &= n[0] == o[0] && n[1] - o[1] == -1 && n[2] == o[2];          // next row = one block down
                    }
                }
                TestMain.check(tag + ": cells distinct, columns step to viewer's right, rows step down", distinct && adjacent);
                TestMain.check(tag + ": bounding box spans exactly cols x rows",
                        (nx == 0 ? maxX - minX : maxZ - minZ) == cols && maxY - minY == rows
                                && (nx == 0 ? maxZ - minZ : maxX - minX) == 1);
                TestMain.check(tag + ": anchor is the bottom-left cell (row rows-1, col 0 at offset 0,0,0)",
                        java.util.Arrays.equals(ScreenGeometry.cellOffset(nx, nz, rows, rows - 1, 0), new int[]{0, 0, 0}));
                double[] ce = ScreenGeometry.center(nx, nz, cols, rows);
                // in-plane axes must equal the centre of the brute-force bounding box; depth axis = map surface
                double bx = (minX + maxX) / 2.0, by = (minY + maxY) / 2.0, bz = (minZ + maxZ) / 2.0;
                boolean ok = Math.abs(ce[1] - by) < EPS;
                if (nx == 0) {      // plane axis = x, depth axis = z
                    ok &= Math.abs(ce[0] - bx) < EPS;
                    double wallZ = nz == 1 ? 0.0 : 1.0;                       // wall is at -n side of the block
                    ok &= Math.abs(ce[2] - (wallZ + nz * ScreenGeometry.SURFACE_FROM_WALL)) < EPS;
                } else {            // plane axis = z, depth axis = x
                    ok &= Math.abs(ce[2] - bz) < EPS;
                    double wallX = nx == 1 ? 0.0 : 1.0;
                    ok &= Math.abs(ce[0] - (wallX + nx * ScreenGeometry.SURFACE_FROM_WALL)) < EPS;
                }
                TestMain.check(tag + ": centre = middle of whole screen (not anchor/mid block), on the map surface", ok);
                if (cols == 1 && rows == 1)
                    TestMain.check(tag + ": 1x1 centre is the block's horizontal middle", Math.abs(ce[1] - 0.5) < EPS);
                if (cols == 2 && rows == 2 && nz == -1)
                    TestMain.check(tag + ": 2x2 NORTH centre known value (x=0,y=1,z=0.9375 rel. anchor)",
                            Math.abs(ce[0] - 0.0) < EPS && Math.abs(ce[1] - 1.0) < EPS && Math.abs(ce[2] - 0.9375) < EPS);
            }
        }
    }
}
