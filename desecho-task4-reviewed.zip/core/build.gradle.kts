plugins { `java-library` }

java { toolchain { languageVersion = JavaLanguageVersion.of(25) } }

// The existing tests are plain main() programs (not JUnit). Run them with:
//   ./gradlew :core:coreChecks :core:coreIntegration     (integration needs ffmpeg on PATH)
val testClasses = sourceSets["test"].runtimeClasspath
tasks.register<JavaExec>("coreChecks") {
    classpath = testClasses; mainClass = "dev.des.desecho.core.TestMain"; dependsOn("testClasses")
}
tasks.register<JavaExec>("coreIntegration") {
    classpath = testClasses; mainClass = "dev.des.desecho.core.IntegrationTests"; dependsOn("testClasses")
}
