# DESECHO

DESECHO is a source project for a Paper plugin that displays local MP4 video on a physical wall of filled-map item frames. Its core engine uses FFmpeg for video decoding and audio extraction. The Paper plugin connects the picture to map rendering and sends shared screen audio through Plasmo Voice.

**Important status:** the Paper plugin source exists, but this project has not yet been compiled against the actual Paper/Plasmo dependencies or tested on a Minecraft server. Treat it as an implementation candidate, not an install-ready plugin. No JAR is included.

## Implemented source areas

- `core/`: media commands and decoding, frame queues, playback clock/session management, frame pacing, palette quantization, screen geometry, and the clock-paced PCM audio feeder.
- `plugin/`: Paper plugin lifecycle and commands, map/item-frame screens, map ID reuse, chunk-ticket tracking, viewer updates, and the Plasmo Voice bridge.
- Local media flow: place an MP4 in `plugins/DESECHO/media/` and use `/desecho play <screen> file:<filename>`.
- Shared audio design: one Plasmo Voice source/provider/sender per screen; every nearby player with the Plasmo Voice client mod should receive that screen's audio. This still needs a real multiplayer test.

## Target environment

- Java 25
- Paper 26.2 (Gradle API dependency currently pinned to `26.2.build.135-stable`)
- Plasmo Voice server API 2.1.16
- FFmpeg available on PATH, or configured with `ffmpeg-path`
- Plasmo Voice client mod installed and connected on every player who should hear audio

See `SETUP.md` for the setup notes and first test commands.

## Source checks vs runtime verification

The ZIP includes recorded core test output: 122 unit checks in `test-run.txt` and 42 engine integration checks in `integration-run.txt`. These records are from the earlier core-engine pass; they were not rerun during the Task 4 source review. `GeometryChecks` is invoked by `TestMain` for the recorded geometry coverage.

Not yet verified:

- Compilation of the Paper plugin against Paper 26.2 and Plasmo Voice 2.1.16.
- Plugin startup/shutdown on a real Paper server.
- Physical frame placement and map rendering on all four wall facings.
- Audible shared sound on two or more separate Minecraft accounts.
- Audio/video startup alignment, pause/resume/seek under real network conditions.
- Performance with the intended screen sizes and concurrent sessions.

See `TASK4_INSPECTION.md` and `PLUGIN_STATUS.md` for the current audit findings. No build or JAR has been produced as part of this review.
