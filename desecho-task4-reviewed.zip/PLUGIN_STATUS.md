# DESECHO plugin status

## Current state

The repository contains both the core playback engine and the Paper plugin source. There is **no JAR** in this project, and the Paper plugin has **not** been compiled against the declared Paper/Plasmo dependencies or tested on a live server.

## Target dependencies

| Dependency | Declared target | Review status |
|---|---|---|
| Java | 25 | Gradle toolchain configured; local plugin compilation not performed |
| Paper API | `26.2.build.135-stable` | Artifact listing and Paper 26.2 Javadocs checked; plugin not compiled |
| Plasmo Voice server API | `2.1.16` | Versioned API docs checked for audio sender/provider signatures; plugin not compiled |

`plugin.yml` uses `api-version: '26.2'` and `depend: [PlasmoVoice]`.

## Source components

| File / area | Responsibility | Current status |
|---|---|---|
| `DesechoPlugin.java` | Plugin lifecycle, media directory, FFmpeg detection, session wiring, viewer/audio range updates and cleanup | Source inspected; not compiled |
| `DesechoCommand.java` | Create/play/pause/resume/seek/stop/info/remove commands | Source inspected; size-overflow guard corrected; not compiled |
| `Screen.java` | Physical item-frame map screen, rendering, viewer updates and cleanup | Source inspected; map locking added; not compiled or tested in-game |
| `MapPool.java` | Map ID reuse | Source inspected; reused maps now rebound to the requested world; not compiled |
| `ChunkTickets.java` | Reference-counted plugin chunk tickets | Source inspected; empty-world bookkeeping cleanup added; not compiled |
| `PlasmoVoiceBridge.java` | One shared Plasmo source/provider/sender per screen | Source inspected; sender-stop callback and open-failure cleanup corrected; not compiled |
| `core/` | FFmpeg decoding, shared playback clock, display engine, PCM audio feeder | Prior recorded tests are included; not rerun in this review |

## API findings from the source review

- Paper 26.2 documents `World.addPluginChunkTicket` / `removePluginChunkTicket`; one plugin has only one ticket for a given chunk, which supports the ref-counting design.
- Paper 26.2 `MapView` documents `setWorld` and `setLocked`; the map pool now sets the world on reused views, and the screen locks its map views.
- Paper 26.2 also documents `Player.sendMap(MapView)`, `ItemFrame.setFixed` / `setVisible` / `setItem`, and `Hanging.setFacingDirection`, which are used by the map push and physical frame implementation.
- Plasmo Voice 2.1.16 documents `QueueAudioFrameProvider(voiceServer, stereo)`, `addSamples(short[])` for 48 kHz 16-bit PCM, `clear()` and `close()`.
- Plasmo Voice 2.1.16 documents `AudioSender.onStop(Runnable)` and a nullable `job` property; it does not document an `AudioSender.isActive()` method. The source uses `onStop` to detect sender termination and restart when new PCM arrives, without depending on the deprecated job property.

## Remaining verification

1. Compile using Java 25, Paper API 26.2, and Plasmo Voice API 2.1.16.
2. Resolve any actual compiler diagnostics; source/Javadoc review is not compilation proof.
3. Start a real Paper server and verify plugin load/disable and all commands.
4. Test item-frame placement, map packet updates and cleanup for NORTH/SOUTH/EAST/WEST walls.
5. Test with two Minecraft accounts, both running Plasmo Voice client mod; verify both hear the same stream.
6. Test pause, resume, seek, player range entry/exit, stop, screen removal and server shutdown.
7. Measure map packet/network load and FFmpeg performance at intended screen sizes.

## Known runtime questions

- The Plasmo Voice API describes the nullable `AudioFrameResult.Provided.frame`, but the exact timing/behaviour of an empty `QueueAudioFrameProvider` queue still needs to be confirmed at runtime.
- `AudioFeeder` uses a 300 ms startup lead. The included integration log expects delayed initial delivery, but actual perceived audio/video alignment must be checked in-game.
- The map rendering path still uses legacy map palette/pixel APIs marked deprecated by current Paper. They are left intact to avoid changing palette-index behaviour before a real API compile and rendering test.

No Gradle build, plugin compile, JAR production or Minecraft server test was performed for this review.
