# DESECHO change history

## Core and first plugin integration

- Added the Paper plugin layer around the existing Java core: plugin lifecycle, `/desecho` command handling, map/item-frame screen creation, map view pooling, and local media playback wiring.
- Added the Plasmo Voice bridge: one shared source/provider/sender per screen, loaded as an addon in `onLoad`, with Plasmo Voice declared as a required plugin dependency.
- Wired FFmpeg PCM audio to the Plasmo Voice provider and used the shared playback clock for audio pacing.
- Added playback ownership/permissions, session limits, pause/resume/seek/stop, viewer and listener range handling, FFmpeg checks, and resource cleanup.

## Task 3: screen placement and cleanup

- `Screen.java`: frames spawn at the centre of each air cell, facing is forced during spawn and then checked, and a failed placement triggers cleanup.
- `Screen.java`: screen centre and cell positions use the shared/tested `ScreenGeometry` implementation.
- Screens acquire chunk tickets before spawning and release maps, frames and tickets on failure/removal.
- Added `ChunkTickets.java` with reference counting so multiple screens sharing one chunk do not remove each other's plugin ticket.
- Added viewer-state resets on respawn/world change and geometry checks for four wall facings and several screen sizes.

## Task 4: source/API review (2026-11-17; no build)

- Pinned Paper API to `26.2.build.135-stable`; retained Plasmo Voice API `2.1.16`.
- `MapPool.java`: rebinds cached and persisted `MapView`s to the requested world before reuse.
- `Screen.java`: locks map views after configuring their renderers.
- `DesechoCommand.java`: uses long arithmetic for width × height validation to prevent integer overflow.
- `PlasmoVoiceBridge.java`: uses the documented `AudioSender.onStop(Runnable)` callback to detect sender termination and restart when PCM arrives; removes a created source if provider construction fails; cleans up after sender-start failure.
- `ChunkTickets.java`: removes empty per-world reference-count entries after the last ticket is released.
- Updated README/setup/status documentation to distinguish implemented source from tested runtime functionality.

## Verification boundaries

- The repository includes recorded core test logs: 122 unit checks and 42 engine integration checks. These are earlier recorded results, not rerun as part of Task 4.
- Paper/Plasmo plugin compilation, Paper server startup, physical screen rendering, and two-client Plasmo Voice playback remain unverified.
- No Gradle build or JAR was produced as part of Task 4.
