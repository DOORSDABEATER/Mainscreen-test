> Historical implementation plan. Current source/status and remaining verification are documented in the repository root `README.md`, `PLUGIN_STATUS.md` and `TASK4_INSPECTION.md`; this plan is not the current status checklist.

# DESECHO - implementation plan (written after inspecting the whole codebase)

## 1. Inspection summary
~1,500 lines Java in `core/` (no Paper/Bukkit/Plasmo dependency anywhere), 3 packages added in this step.
| Package | Role | Reuse in plugin |
|---|---|---|
| `permission` | `Actor`, `Action`, `AccessPolicy` | Bukkit layer builds `Actor` from real permission checks |
| `playback` | `SessionManager` (ownership, limits, audit), `PlaybackClock`, `PlaybackSession` | unchanged; one instance per plugin |
| `security` | `UrlGuard` (SSRF), `LocalMediaPolicy` | every URL/file goes through these before ffmpeg |
| `media` | ffmpeg arg builders, decoder process, frame queue/pacer, presets, sanitizer | unchanged |
| `display` | `PaletteQuantizer`, `PanelDiff` | Paper layer builds the palette from the running server, feeds diffs to maps |
| **`engine` (new)** | `ScreenPlayer` (picture), `AudioFeeder` (20 ms PCM frames), `DisplaySink`, `PcmSink` | the two seams the plugin implements |

Nothing existing was replaced. Only additive change to existing code: `SessionManager.end()` (natural end of media).

## 2. Seams the plugin must fill (all Paper/Plasmo specific, none written yet)
* `DisplaySink` -> run `PanelDiff`, send changed map regions to viewers who are in range; main-thread hand-off.
* `hasViewers` -> concurrent set maintained from player move/join/quit events and range checks.
* `PcmSink` -> Plasmo Voice static audio source at the screen's location; `hasListeners` -> players in audio range.
* `Actor` factory, command executor + tab completion, display registry + storage, plugin lifecycle (shutdown = `stopAll` + close players).

## 3. Phases and the gate each must pass before the next starts
| # | Work | Gate (must actually run, not just compile) |
|---|---|---|
| A | Gradle project, `plugin.yml`/`paper-plugin.yml`, entry point, config, shaded core | JAR loads on the target Paper build; `/desecho status` answers |
| B | Display registry + storage (SQLite via whatever the server provides) + `/desecho create/delete/configure/screens` | create screen, restart server, screen still there |
| C | Map rendering: virtual map ids + item-frame (or packet) surface, per-viewer delivery, `DisplaySink` | test pattern visible on a real screen to a real client |
| D | `/desecho play|stop|pause|resume|seek|volume|mute|info` + real permission mapping + MP4 | two players, owner/non-owner/OP matrix run in-game |
| E | Plasmo Voice addon + `PcmSink` + range/volume/mute | two players hear it, attenuates with distance, pause/seek in sync |
| F | Provider SPI + yt-dlp (YouTube etc.), HLS/DASH, per-hop `UrlGuard` | real YouTube URL plays; failures give stage-tagged messages |
| G | Limits, rate-limit, diagnostics, docs, acceptance run of all 30 tests | recorded results |

## 4. Open technical decisions (cannot be settled without the real jars / a real server)
1. **Map delivery API** on the target Paper build: Bukkit `MapView`/`MapRenderer` + `Player.sendMap` vs raw packets. Prefer the Bukkit API if it supports partial updates per player.
2. **Surface**: invisible, non-persistent item frames holding filled maps vs packet-only entities. Must not leave entities in the world after a crash.
3. **Plasmo Voice API**: exact static-source and audio-sender calls and the PCM format it expects (the feeder emits 48 kHz mono s16le, 960-sample frames; unverified).
4. **Storage**: whether an SQLite JDBC driver is available at runtime on that server; otherwise shade one.
5. **Bandwidth/FPS**: measure real achievable FPS per screen size per viewer count; the quality presets are decode caps only.

## 5. Blockers found in this sandbox (why items below are not done)
* No Paper API jar, no Plasmo Voice jar, no server jar, no audit output from your server (`desecho-audit.txt` was never provided).
* Sandbox has JDK **21** (no `javac` binary; compiler used via `jdk.compiler` module) and **no network**. A Paper build for Minecraft 26.x
  almost certainly needs **Java 25**; class files from it cannot be read by javac 21, and a Paper server cannot be started here.
* No yt-dlp, no Gradle/Maven, no SQLite JDBC driver.
So: compiling against the real API, loading the plugin, and every in-game test are impossible until one of the unblock options in section 7.

## 6. Status of the 10 requested items
| # | Item | Status |
|---|---|---|
| 1 | Paper plugin structure + entry point | **Not started** (needs target API) |
| 2 | Integrate core | Engine layer **done and tested** (`engine/`); plugin wiring **not started** |
| 3 | Map-rendered displays | Quantizer + partial-update diff **done/tested**; Paper rendering **not started** |
| 4 | Commands + permissions | Permission/ownership logic **done/tested** (122 unit checks); Bukkit commands **not started** |
| 5 | Direct MP4 playback | Engine **done and tested vs real ffmpeg**; in-world playback **not started** |
| 6 | Plasmo Voice audio | PCM pacing against shared clock **done/tested**; Plasmo API integration **not started** |
| 7 | Persistent displays/ownership | **Not started** (ownership is UUID-based in memory only) |
| 8 | YouTube/other providers | **Not started** (needs yt-dlp; `UrlGuard` ready for returned URLs) |
| 9 | Test against actual Paper/Plasmo versions | **Not possible yet** |
| 10 | Preserve tests, add integration tests | **Done**: 122 unit + 42 engine integration, all passing (3 consecutive runs) |

## 7. How to unblock (pick one)
* **A (best):** allow sandbox network access (papermc.io, repo.plasmovoice.com, GitHub, Adoptium/JDK 25 download). I can then fetch the JDK, Paper and Plasmo Voice,
  build the plugin with Gradle, and run a real headless Paper server for load/command/persistence tests. Real-client map and audio checks (C, E) still need people in-game.
* **B:** upload the exact server jar, the Plasmo Voice plugin jar + its API jar(s), and `desecho-audit.txt` + `/version` + `/plugins` output. I can read the real API, but still can't run Java 25 here.
* **C:** I write the plugin + Gradle build; you build on a machine with JDK 25 and paste compile errors/logs back. Slowest, least verified.
