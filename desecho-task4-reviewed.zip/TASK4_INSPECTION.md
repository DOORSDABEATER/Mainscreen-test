# DESECHO Task 4 inspection report

Date: 2026-11-17
Input: `desecho-source-task3.zip`
Output: updated source ZIP only

## Files inspected

- Root/build metadata: `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `plugin/build.gradle.kts`, `core/build.gradle.kts`.
- Plugin metadata/resources: `plugin/src/main/resources/plugin.yml`, `config.yml`.
- Paper plugin source: `DesechoPlugin.java`, `DesechoCommand.java`, `Screen.java`, `MapPool.java`, `ChunkTickets.java`, `VoiceBridge.java`, `PlasmoVoiceBridge.java`.
- Core source: display, engine, media, permission, playback and security packages.
- Core test sources and included recorded logs: `GeometryChecks.java`, `IntegrationTests.java`, `TestMain.java`, `test-run.txt`, `integration-run.txt`.
- Project documentation: `README.md`, `SETUP.md`, `PLUGIN_STATUS.md`, `CHANGES.md`, `docs/IMPLEMENTATION_PLAN.md`.

## Files changed

| File | Change |
|---|---|
| `gradle.properties` | Pin Paper API to `26.2.build.135-stable`; retain Plasmo Voice API `2.1.16`. |
| `plugin/src/main/resources/plugin.yml` | Clarify the 26.2 API target; descriptor already declared `api-version: '26.2'` and Plasmo dependency. |
| `plugin/src/main/java/dev/des/desecho/plugin/MapPool.java` | Reassign cached and persisted MapViews to the screen's current world before reuse. |
| `plugin/src/main/java/dev/des/desecho/plugin/Screen.java` | Lock configured map views against exploration. |
| `plugin/src/main/java/dev/des/desecho/plugin/DesechoCommand.java` | Use long multiplication for the width × height limit check. |
| `plugin/src/main/java/dev/des/desecho/plugin/PlasmoVoiceBridge.java` | Use documented `AudioSender.onStop(Runnable)` rather than a nonexistent sender-level `isActive`; remove the source if provider construction fails; clean up on sender-start failure; update API comments. |
| `plugin/src/main/java/dev/des/desecho/plugin/ChunkTickets.java` | Remove empty per-world maps from reference-count bookkeeping. |
| `README.md`, `SETUP.md`, `PLUGIN_STATUS.md`, `CHANGES.md` | Correct stale claims and document current implementation and verification boundaries. |

## API review findings

The relevant API references used for this review are the [Paper 26.2 Javadocs](https://jd.papermc.io/paper/26.2/), the [Plasmo Voice 2.1.16 AudioSender API](https://dokka.plasmovoice.com/older/2.1.16/server-proxy-common/su.plo.voice.api.server.audio.source/-audio-sender/index.html), and the [Plasmo Voice 2.1.16 QueueAudioFrameProvider API](https://dokka.plasmovoice.com/older/2.1.16/server-proxy-common/su.plo.voice.api.server.audio.provider/-queue-audio-frame-provider/index.html).

### Paper 26.2

- Paper's published 26.2 API artifact is `26.2.build.135-stable`; the matching Javadocs expose `World.addPluginChunkTicket` and `removePluginChunkTicket`, and explain that a plugin has one ticket per chunk. The reference-counted approach is appropriate for multiple screens sharing the same chunk.
- `MapView` exposes `setWorld(World)` and `setLocked(boolean)`, used by the two corrections above.
- `Player.sendMap(MapView)`, `ItemFrame.setFixed` / `setVisible` / `setItem`, and `Hanging.setFacingDirection(BlockFace, boolean)` are also present in the Paper 26.2 Javadocs and match the source usage.
- This was documentation/source review only. It does not replace compilation against the actual JAR.

### Plasmo Voice 2.1.16

- The versioned 2.1.16 API docs expose `QueueAudioFrameProvider(PlasmoBaseVoiceServer, boolean)`, `addSamples(ShortArray)` for 48 kHz 16-bit PCM, `clear()` and `close()`.
- The versioned `AudioSender` API exposes `onStop(Runnable)` (called when its sender coroutine job stops) and a nullable `job` property; it does not expose an `AudioSender.isActive()` method. The source registers `onStop` and restarts the sender when PCM arrives after a stop, avoiding reliance on the deprecated `job` property.
- The docs define `AudioFrameResult.Provided` with a nullable frame but do not fully describe queue-empty scheduling behaviour. Runtime verification remains necessary.

## Recorded test evidence

The archive includes logs reporting 122 unit checks and 42 engine integration checks. These are pre-existing recorded logs. I did not rerun them in this review and they do not test Paper/Plasmo runtime integration. The geometry checks are present in `core/src/test` and wired through `TestMain`.

## Not performed

- No Gradle invocation.
- No Java/Paper/Plasmo compilation.
- No JAR production.
- No Paper server startup.
- No physical item-frame/map rendering test.
- No Plasmo Voice playback or two-account test.

## Still required before calling DESECHO working

1. Compile locally with Java 25 and the pinned Paper/Plasmo dependencies; resolve any actual compiler errors.
2. Test plugin startup and shutdown on Paper 26.2.
3. Verify physical frame placement and map rendering on all four wall facings.
4. Test the audio sender/provider on a real server, especially an empty queue and sender restart after pause/seek.
5. Test MP4 audio/video with at least two accounts and verify startup alignment, pause, resume, seek, range handling, stop and cleanup.
6. Benchmark the map update load with the intended screen sizes.

**Assessment:** the source has received targeted corrections and the documented API signatures now align better with the stated targets. It is not yet proven to compile or run. The next milestone is the user's local compile, followed by a real Paper server test.
