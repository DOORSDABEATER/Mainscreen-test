package dev.des.desecho.plugin;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.map.MapView;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Reuses map ids across screens/restarts so creating screens does not leak map_N.dat files forever. Main thread only. */
final class MapPool {
    private final File file;
    private final List<Integer> known = new ArrayList<>();
    private final Set<Integer> inUse = new HashSet<>();
    private final java.util.ArrayDeque<MapView> free = new java.util.ArrayDeque<>();

    MapPool(File dataFolder) {
        this.file = new File(dataFolder, "maps.yml");
        if (file.isFile()) known.addAll(YamlConfiguration.loadConfiguration(file).getIntegerList("ids"));
    }

    MapView acquire(World world) {
        MapView cached = free.poll();
        if (cached != null) {
            @SuppressWarnings("deprecation") int cid = cached.getId();
            cached.setWorld(world);
            inUse.add(cid);
            return cached;
        }
        for (int id : known) {
            if (inUse.contains(id)) continue;
            @SuppressWarnings("deprecation") MapView v = Bukkit.getMap(id);
            if (v != null) {
                v.setWorld(world);
                inUse.add(id);
                return v;
            }
        }
        MapView v = Bukkit.createMap(world);
        @SuppressWarnings("deprecation") int id = v.getId();
        known.add(id);
        inUse.add(id);
        save();
        return v;
    }

    void release(MapView v) {
        @SuppressWarnings("deprecation") int id = v.getId();
        inUse.remove(id);
        if (!free.contains(v)) free.add(v);   // idempotent: releasing twice must not hand the same map to two panels
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("ids", known);
        try { y.save(file); } catch (IOException ignored) { }
    }
}
