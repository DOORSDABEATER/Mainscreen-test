package dev.des.desecho.plugin;

import org.bukkit.World;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Reference-counted plugin chunk tickets. Paper keeps ONE plugin ticket per (plugin, chunk), not a count, so two screens
 * sharing a chunk must not remove each other's ticket. Main thread only.
 */
final class ChunkTickets {
    private final Plugin plugin;
    private final Map<UUID, Map<Long, Integer>> counts = new HashMap<>();

    ChunkTickets(Plugin plugin) { this.plugin = plugin; }

    static long key(int cx, int cz) { return ((long) cx << 32) | (cz & 0xffffffffL); }

    void acquire(World w, int cx, int cz) {
        Map<Long, Integer> m = counts.computeIfAbsent(w.getUID(), k -> new HashMap<>());
        int n = m.merge(key(cx, cz), 1, Integer::sum);
        if (n == 1) w.addPluginChunkTicket(cx, cz, plugin);
    }

    void release(World w, int cx, int cz) {
        Map<Long, Integer> m = counts.get(w.getUID());
        if (m == null) return;
        Integer n = m.get(key(cx, cz));
        if (n == null) return;
        if (n <= 1) {
            m.remove(key(cx, cz));
            w.removePluginChunkTicket(cx, cz, plugin);
            if (m.isEmpty()) counts.remove(w.getUID());
        } else m.put(key(cx, cz), n - 1);
    }
}
