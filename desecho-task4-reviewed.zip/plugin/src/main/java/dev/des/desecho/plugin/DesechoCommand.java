package dev.des.desecho.plugin;

import dev.des.desecho.core.permission.Action;
import dev.des.desecho.core.permission.AccessPolicy;
import dev.des.desecho.core.playback.PlaybackSession;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class DesechoCommand implements TabExecutor {
    private final DesechoPlugin pl;
    private DesechoCommand(DesechoPlugin pl) { this.pl = pl; }

    static void register(DesechoPlugin pl) {
        org.bukkit.command.PluginCommand c = pl.getCommand("desecho");
        DesechoCommand h = new DesechoCommand(pl);
        c.setExecutor(h); c.setTabCompleter(h);
    }

    private static final List<String> SUBS = List.of("help", "create", "play", "pause", "resume", "stop", "seek", "info", "remove");

    @Override public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0 || a[0].equalsIgnoreCase("help")) { help(s); return true; }
        try {
            switch (a[0].toLowerCase(Locale.ROOT)) {
                case "create" -> create(s, a);
                case "play" -> play(s, a);
                case "pause" -> ctl(s, a, "pause");
                case "resume" -> ctl(s, a, "resume");
                case "stop" -> ctl(s, a, "stop");
                case "seek" -> seek(s, a);
                case "info" -> info(s, a);
                case "remove" -> remove(s, a);
                default -> s.sendMessage("§cUnknown subcommand. /desecho help");
            }
        } catch (RuntimeException e) {
            s.sendMessage("§cInternal error: " + e.getClass().getSimpleName() + " (see console)");
            pl.getLogger().warning("command failed: " + e);
        }
        return true;
    }

    private void help(CommandSender s) {
        s.sendMessage("§6/desecho create <name> <width> <height> §7- look at the wall block for the screen's BOTTOM-LEFT corner");
        s.sendMessage("§6/desecho play <name> file:<filename> §7- file in plugins/DESECHO/media/");
        s.sendMessage("§6/desecho pause|resume|stop <name>");
        s.sendMessage("§6/desecho seek <name> <timestamp> §7- 90, 1:30 or 1:02:03");
        s.sendMessage("§6/desecho info <name>   /desecho remove <name>");
        s.sendMessage("§7Voice: " + pl.voice.status() + (pl.voice.available() ? "" : " §c(NO AUDIO)"));
    }

    private void create(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("§cIn-game only."); return; }
        if (!AccessPolicy.check(pl.actor(s), Action.CREATE_DISPLAY, null).allowed()) { s.sendMessage("§cYou don't have permission to manage displays."); return; }
        if (a.length != 4) { s.sendMessage("§cUsage: /desecho create <name> <width> <height>"); return; }
        String name = a[1].toLowerCase(Locale.ROOT);
        if (!name.matches("[a-z0-9_-]{1,32}")) { s.sendMessage("§cName must match [a-z0-9_-], max 32."); return; }
        if (pl.screens.containsKey(name)) { s.sendMessage("§cA screen with that name exists."); return; }
        int w, h;
        try { w = Integer.parseInt(a[2]); h = Integer.parseInt(a[3]); } catch (NumberFormatException e) { s.sendMessage("§cWidth/height must be numbers."); return; }
        if (w < 1 || h < 1 || (long) w * (long) h > pl.getConfig().getInt("max-maps", 64)) { s.sendMessage("§cSize must be >=1 and at most " + pl.getConfig().getInt("max-maps", 64) + " maps total."); return; }
        RayTraceResult r = p.rayTraceBlocks(8);
        if (r == null || r.getHitBlock() == null || r.getHitBlockFace() == null) { s.sendMessage("§cLook at a wall block within 8 blocks."); return; }
        BlockFace face = r.getHitBlockFace();
        if (face != BlockFace.NORTH && face != BlockFace.SOUTH && face != BlockFace.EAST && face != BlockFace.WEST) { s.sendMessage("§cScreens go on vertical walls: aim at the side of a block."); return; }
        Block anchor = r.getHitBlock().getRelative(face);
        Object[] res = Screen.build(name, anchor, face, w, h, pl.pool);
        if (res[0] == null) { s.sendMessage("§c" + res[1]); return; }
        pl.screens.put(name, (Screen) res[0]);
        s.sendMessage("§aScreen '" + name + "' created (" + w + "x" + h + " maps = " + w * 128 + "x" + h * 128 + " px). Voice: " + pl.voice.status());
    }

    private Screen screen(CommandSender s, String[] a, int min) {
        if (a.length < min) { s.sendMessage("§cMissing arguments. /desecho help"); return null; }
        Screen sc = pl.screens.get(a[1].toLowerCase(Locale.ROOT));
        if (sc == null) s.sendMessage("§cNo screen named '" + a[1] + "'.");
        return sc;
    }

    private void play(CommandSender s, String[] a) {
        if (a.length != 3) { s.sendMessage("§cUsage: /desecho play <name> file:<filename>"); return; }
        Screen sc = screen(s, a, 3);
        if (sc == null) return;
        if (!a[2].startsWith("file:")) { s.sendMessage("§cOnly local files are supported: file:<filename>"); return; }
        for (String line : pl.play(s, sc, a[2].substring(5))) s.sendMessage(line);
    }

    private void ctl(CommandSender s, String[] a, String what) {
        if (a.length != 2) { s.sendMessage("§cUsage: /desecho " + what + " <name>"); return; }
        Screen sc = screen(s, a, 2);
        if (sc == null) return;
        var act = pl.actor(s);
        var res = switch (what) {
            case "pause" -> pl.mgr.pause(act, sc.name);
            case "resume" -> pl.mgr.resume(act, sc.name);
            default -> pl.mgr.stop(act, sc.name);
        };
        s.sendMessage((res.ok() ? "§a" : "§c") + res.message());
        if (res.ok() && what.equals("stop")) pl.endRun(sc.name);
    }

    private void seek(CommandSender s, String[] a) {
        if (a.length != 3) { s.sendMessage("§cUsage: /desecho seek <name> <timestamp>"); return; }
        Screen sc = screen(s, a, 3);
        if (sc == null) return;
        long ms = parseTime(a[2]);
        if (ms < 0) { s.sendMessage("§cBad timestamp. Use seconds (90), m:ss (1:30) or h:mm:ss."); return; }
        var res = pl.mgr.seek(pl.actor(s), sc.name, ms);
        s.sendMessage((res.ok() ? "§aSeeked to " + a[2] + " (picture and audio resume there; audio restarts within a moment)." : "§c" + res.message()));
    }

    static long parseTime(String t) {
        try {
            String[] p = t.split(":");
            long sec = 0;
            if (p.length > 3) return -1;
            for (String x : p) { long v = Long.parseLong(x); if (v < 0) return -1; sec = sec * 60 + v; }
            return sec * 1000;
        } catch (NumberFormatException e) { return -1; }
    }

    private void info(CommandSender s, String[] a) {
        Screen sc = screen(s, a, 2);
        if (sc == null) return;
        s.sendMessage("§6Screen '" + sc.name + "' §7" + sc.cols + "x" + sc.rows + " maps, world " + sc.world.getName() + ", viewers in range: " + sc.viewers.size() + ", audio listeners: " + sc.listeners.size());
        PlaybackSession ps = pl.mgr.get(sc.name).orElse(null);
        DesechoPlugin.Run run = pl.runs.get(sc.name);
        if (ps == null) { s.sendMessage("§7Idle. Voice: " + pl.voice.status()); return; }
        s.sendMessage("§7State: " + ps.state() + "  position: " + fmt(ps.clock().positionMs()) + "  source: " + ps.source() + "  volume: " + ps.volume() + (ps.muted() ? " (muted)" : ""));
        if (run != null && run.player != null) s.sendMessage("§7Frames presented: " + run.player.framesPresented() + "  decoding: " + run.player.isDecoding());
        if (run != null) s.sendMessage("§7Audio: " + (run.feeder == null ? "OFF - " + run.audioNote
                : (run.feeder.isDecoding() ? "ACTIVE, " : "idle (no listener in range or paused), ") + "delivered " + run.feeder.delivered() + " frames, dropped " + run.feeder.dropped() + ", restarts " + run.feeder.restarts()));
    }

    private static String fmt(long ms) { long t = ms / 1000; return String.format("%d:%02d:%02d", t / 3600, t / 60 % 60, t % 60); }

    private void remove(CommandSender s, String[] a) {
        Screen sc = screen(s, a, 2);
        if (sc == null) return;
        if (!AccessPolicy.check(pl.actor(s), Action.DELETE_DISPLAY, null).allowed()) { s.sendMessage("§cYou don't have permission to manage displays."); return; }
        if (pl.mgr.get(sc.name).isPresent()) {
            var res = pl.mgr.forceStop(pl.actor(s), sc.name);
            if (!res.ok()) { s.sendMessage("§c" + res.message()); return; }
        }
        pl.removeScreen(sc.name);
        s.sendMessage("§aScreen '" + sc.name + "' removed (playback, audio source, frames and maps released).");
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) out.addAll(SUBS);
        else if (a.length == 2 && !a[0].equalsIgnoreCase("create") && !a[0].equalsIgnoreCase("help")) out.addAll(pl.screens.keySet());
        else if (a.length == 3 && a[0].equalsIgnoreCase("play")) {
            String[] f = pl.mediaFolder().list();
            if (f != null) for (String n : f) out.add("file:" + n);
        }
        else if (a.length == 3 && a[0].equalsIgnoreCase("create")) out.addAll(List.of("2", "4", "6"));
        else if (a.length == 4 && a[0].equalsIgnoreCase("create")) out.addAll(List.of("2", "3", "4"));
        else if (a.length == 3 && a[0].equalsIgnoreCase("seek")) out.addAll(List.of("0", "30", "1:00"));
        String last = a[a.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
