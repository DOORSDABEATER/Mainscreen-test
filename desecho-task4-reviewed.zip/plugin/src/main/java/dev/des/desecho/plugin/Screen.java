package dev.des.desecho.plugin;

import dev.des.desecho.core.display.ScreenGeometry;
import dev.des.desecho.core.engine.DisplaySink;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.map.MapCanvas;
import org.bukkit.map.MapRenderer;
import org.bukkit.map.MapView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicIntegerArray;

/**
 * A physical screen: cols x rows invisible item frames on a wall, each holding a filled map.
 * Panel index i = row * cols + col, row 0 = TOP. Frame data (panels[]) is written by the presenter
 * thread (DisplaySink) and read on the main thread (renderer / sendMap), guarded by synchronized(panel).
 */
final class Screen implements DisplaySink {
    static final int MAP = 128;

    final String name;
    final World world;
    final int cols, rows;
    final BlockFace facing;
    final Location center;
    final MapView[] views;
    final UUID[] frameIds;
    private final byte[][] panels;
    private final AtomicIntegerArray versions;
    private final byte[] tmp = new byte[MAP * MAP];   // presenter thread only
    final Map<UUID, int[]> lastSent = new ConcurrentHashMap<>();
    volatile Set<UUID> viewers = Set.of();
    volatile Set<UUID> listeners = Set.of();
    volatile boolean removed;
    private final java.util.Set<Long> tickets = new java.util.HashSet<>();   // chunks this screen holds a ref-counted ticket on
    private ChunkTickets ticketMgr;

    private Screen(String name, World world, int cols, int rows, BlockFace facing, Location center) {
        this.name = name; this.world = world; this.cols = cols; this.rows = rows; this.facing = facing; this.center = center;
        int n = cols * rows;
        this.views = new MapView[n];
        this.frameIds = new UUID[n];
        this.panels = new byte[n][MAP * MAP];
        this.versions = new AtomicIntegerArray(n);
    }

    int width() { return cols * MAP; }
    int height() { return rows * MAP; }
    int panelCount() { return cols * rows; }
    int version(int i) { return versions.get(i); }

    /** @return null on success, otherwise a human-readable reason. anchor = AIR block at the screen's BOTTOM-LEFT as seen by a viewer. */
    static Object[] build(String name, Block anchor, BlockFace face, int cols, int rows, MapPool pool) {
        int nx = face.getModX(), nz = face.getModZ();
        Block[][] cells = new Block[rows][cols];     // [rowFromTop][col]
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int[] o = ScreenGeometry.cellOffset(nx, nz, rows, r, c);     // single source of truth (unit-tested in core)
                Block b = anchor.getRelative(o[0], o[1], o[2]);
                if (!b.getType().isAir()) return new Object[]{null, "Not enough free space: block at " + b.getX() + "," + b.getY() + "," + b.getZ() + " is not air."};
                Block back = b.getRelative(face.getOppositeFace());
                if (!back.getType().isSolid()) return new Object[]{null, "The wall behind " + b.getX() + "," + b.getY() + "," + b.getZ() + " is not solid. Find a flat wall."};
                cells[r][c] = b;
            }
        }
        // Physical centre of the whole screen surface (ScreenGeometry, unit-tested in core), NOT the anchor/mid block.
        double[] off = ScreenGeometry.center(face.getModX(), face.getModZ(), cols, rows);
        Location center = new Location(anchor.getWorld(), anchor.getX() + off[0], anchor.getY() + off[1], anchor.getZ() + off[2]);
        Screen s = new Screen(name, anchor.getWorld(), cols, rows, face, center);
        org.bukkit.plugin.Plugin plugin = org.bukkit.plugin.java.JavaPlugin.getPlugin(DesechoPlugin.class);
        s.ticketMgr = ((DesechoPlugin) plugin).tickets;
        try {
            // Tickets FIRST so every frame's chunk is loaded while spawning; destroy() releases them on failure.
            for (Block[] row : cells) for (Block b : row) {
                int cx = b.getX() >> 4, cz = b.getZ() >> 4;
                if (s.tickets.add(ChunkTickets.key(cx, cz))) s.ticketMgr.acquire(anchor.getWorld(), cx, cz);
            }
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    int i = r * cols + c;
                    MapView v = pool.acquire(anchor.getWorld());
                    s.views[i] = v;                      // recorded immediately so a failure below releases it
                    for (MapRenderer old : new ArrayList<>(v.getRenderers())) v.removeRenderer(old);
                    v.setScale(MapView.Scale.CLOSEST);
                    v.setTrackingPosition(false);
                    v.setUnlimitedTracking(false);
                    v.setLocked(true);
                    v.addRenderer(new Panel(s, i));
                    ItemStack item = new ItemStack(Material.FILLED_MAP);
                    MapMeta meta = (MapMeta) item.getItemMeta();
                    meta.setMapView(v);
                    item.setItemMeta(meta);
                    // Hanging entities live in the AIR block in front of the wall; spawn at that block's CENTRE so the
                    // block position can never round into a neighbour. The facing is forced inside the spawn consumer
                    // (before the entity is added): facing = the side the picture shows on = wall-normal, wall is behind.
                    Block cell = cells[r][c];
                    ItemFrame f = anchor.getWorld().spawn(cell.getLocation().add(0.5, 0.5, 0.5), ItemFrame.class, fr -> {
                        fr.setFacingDirection(face, true);
                        fr.setVisible(false);
                        fr.setFixed(true);
                        fr.setInvulnerable(true);
                        fr.setPersistent(false);          // never saved: a crash cannot leave orphan frames
                        fr.setItem(item, false);
                    });
                    s.frameIds[i] = f.getUniqueId();     // recorded immediately so a failure below removes it
                    // Verify what the server actually did; never trust the auto-attach of World#spawn.
                    if (f.getFacing() != face) f.setFacingDirection(face, true);
                    Block at = f.getLocation().getBlock();
                    if (f.getFacing() != face || at.getX() != cell.getX() || at.getY() != cell.getY() || at.getZ() != cell.getZ())
                        throw new IllegalStateException("item frame " + i + " ended up at " + at.getX() + "," + at.getY() + "," + at.getZ()
                                + " facing " + f.getFacing() + " (wanted " + cell.getX() + "," + cell.getY() + "," + cell.getZ() + " facing " + face + ")");
                }
            }
        } catch (RuntimeException ex) {
            s.destroy(pool);                             // removes spawned frames, releases maps, releases chunk tickets
            return new Object[]{null, "Could not place the screen: " + ex.getClass().getSimpleName() + (ex.getMessage() == null ? "" : ": " + ex.getMessage())};
        }
        s.clear();
        return new Object[]{s, null};
    }

    /** Main thread: send changed panels to each viewer. */
    void push() {
        if (removed) return;
        int n = panelCount();
        for (UUID id : viewers) {
            Player p = org.bukkit.Bukkit.getPlayer(id);
            if (p == null || !p.isOnline() || p.getWorld() != world) continue;
            int[] last = lastSent.computeIfAbsent(id, k -> { int[] a = new int[n]; Arrays.fill(a, -1); return a; });
            for (int i = 0; i < n; i++) {
                int v = versions.get(i);
                if (last[i] != v) { p.sendMap(views[i]); last[i] = v; }
            }
        }
        lastSent.keySet().removeIf(id -> !viewers.contains(id));
    }

    /** Main thread. Removes frames, releases maps and chunk tickets. Idempotent; one failing step never skips the rest. */
    void destroy(MapPool pool) {
        removed = true;
        for (int i = 0; i < frameIds.length; i++) {
            try {
                if (frameIds[i] != null) {
                    Entity e = world.getEntity(frameIds[i]);
                    if (e != null) e.remove();
                }
            } catch (RuntimeException ignored) { }
            frameIds[i] = null;
            try {
                if (views[i] != null) {
                    for (MapRenderer r : new ArrayList<>(views[i].getRenderers())) views[i].removeRenderer(r);
                }
            } catch (RuntimeException ignored) { }
            try {
                if (views[i] != null) pool.release(views[i]);
            } catch (RuntimeException ignored) { }
            views[i] = null;
        }
        lastSent.clear();
        if (ticketMgr != null) {
            for (long t : tickets) {
                try { ticketMgr.release(world, (int) (t >> 32), (int) t); } catch (RuntimeException ignored) { }
            }
        }
        tickets.clear();
    }

    boolean ownsFrame(UUID id) {
        for (UUID f : frameIds) if (id.equals(f)) return true;
        return false;
    }

    // ---- DisplaySink (presenter thread; NO Bukkit calls here) ----
    @Override public void present(byte[] canvas) {
        int W = width();
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                for (int y = 0; y < MAP; y++) System.arraycopy(canvas, (r * MAP + y) * W + c * MAP, tmp, y * MAP, MAP);
                int i = r * cols + c;
                synchronized (panels[i]) {
                    if (!Arrays.equals(panels[i], tmp)) { System.arraycopy(tmp, 0, panels[i], 0, tmp.length); versions.incrementAndGet(i); }
                }
            }
        }
    }

    @Override public void clear() {
        for (int i = 0; i < panels.length; i++) {
            synchronized (panels[i]) {
                boolean blank = true;
                for (byte b : panels[i]) if (b != 0) { blank = false; break; }
                if (!blank) { Arrays.fill(panels[i], (byte) 0); versions.incrementAndGet(i); }   // no update for an already-blank panel
            }
        }
    }

    private static final class Panel extends MapRenderer {
        private final Screen s; private final int i;
        Panel(Screen s, int i) { super(false); this.s = s; this.i = i; }
        @SuppressWarnings("deprecation")
        @Override public void render(MapView map, MapCanvas canvas, Player player) {
            byte[] p = s.panels[i];
            synchronized (p) {
                for (int y = 0; y < MAP; y++) for (int x = 0; x < MAP; x++) canvas.setPixel(x, y, p[y * MAP + x]);
            }
        }
    }
}
