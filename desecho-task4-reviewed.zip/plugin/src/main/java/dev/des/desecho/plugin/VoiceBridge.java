package dev.des.desecho.plugin;

import org.bukkit.Location;

/** Audio delivery seam. Implementations: PlasmoVoiceBridge (real) or unavailable() (explicit, never pretends). */
interface VoiceBridge {
    /** Output for one screen. accept() takes 20 ms frames of 48 kHz mono s16le (1920 bytes). Thread-safe. */
    interface Output extends AutoCloseable {
        void accept(byte[] frame);
        /** Drop audio that is queued but not yet sent (pause / seek). */
        void flush();
        @Override void close();
    }

    boolean available();
    String status();
    /** @throws IllegalStateException with a user-readable reason */
    Output open(String screenName, Location at, int rangeBlocks);
    void shutdown();

    static VoiceBridge unavailable(String reason) {
        return new VoiceBridge() {
            public boolean available() { return false; }
            public String status() { return reason; }
            public Output open(String n, Location a, int r) { throw new IllegalStateException(reason); }
            public void shutdown() { }
        };
    }
}
