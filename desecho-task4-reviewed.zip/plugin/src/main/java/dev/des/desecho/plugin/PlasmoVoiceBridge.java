package dev.des.desecho.plugin;

import org.bukkit.Location;
import su.plo.voice.api.addon.AddonInitializer;
import su.plo.voice.api.addon.InjectPlasmoVoice;
import su.plo.voice.api.addon.annotation.Addon;
import su.plo.voice.api.server.PlasmoVoiceServer;
import su.plo.voice.api.server.audio.line.ServerSourceLine;
import su.plo.voice.api.server.audio.provider.QueueAudioFrameProvider;
import su.plo.voice.api.server.audio.source.AudioSender;
import su.plo.voice.api.server.audio.source.ServerStaticSource;
import su.plo.voice.api.server.pos.ServerPos3d;
import su.plo.voice.api.server.world.McServerWorld;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Plasmo Voice 2.1.x server API.
 *
 * API status (checked against plasmovoice.com/docs/api and dokka.plasmovoice.com; the 2.1.16 jar itself could NOT be
 * downloaded where this was edited, so nothing here has been compiled):
 *  VERIFIED in docs : @Addon, @InjectPlasmoVoice, AddonInitializer, PlasmoVoiceServer.getAddonsLoader().load(addon) in onLoad,
 *                     getSourceLineManager().createBuilder(addon, name, translationKey, iconResource, weight).build(),
 *                     ServerSourceLine.createStaticSource(ServerPos3d, boolean stereo), new ServerPos3d(world, x, y, z),
 *                     source.createAudioSender(provider, short distance), AudioSender start/stop/pause/resume,
 *                     new QueueAudioFrameProvider(PlasmoBaseVoiceServer, boolean stereo), addSamples(short[]) (48 kHz s16 PCM),
 *                     clear() ("removes all frames"), close() ("closes the encoder and frame provider"), addEnd() (end-of-stream marker).
 *  VERIFIED in 2.1.16 API docs: AudioSender exposes onStop(Runnable), invoked when its sender coroutine job stops. The docs
 *                     also expose a nullable job property (deprecated in that API) but no AudioSender.isActive() method. The bridge
 *                     uses onStop rather than depending on the deprecated property. The docs define Provided(frame: ByteArray?) but
 *                     do not fully specify QueueAudioFrameProvider's empty-queue timing behaviour; that still needs runtime verification.
 *
 * Design: ONE ServerStaticSource + ONE QueueAudioFrameProvider + ONE AudioSender per screen (shared by every listener;
 * Plasmo fans the packets out to players in range). Mono, 48 kHz, 20 ms frames.
 * addEnd() is never called: it would mark end-of-stream and a pause/seek must not end the stream.
 */
@Addon(id = "pv-addon-desecho", name = "DESECHO", version = "0.1.0", authors = {"DESECHO"})
public final class PlasmoVoiceBridge implements VoiceBridge, AddonInitializer {
    /** Injected by Plasmo "right before onAddonInitialize" (docs). Null before that. */
    @InjectPlasmoVoice
    private PlasmoVoiceServer voiceServer;

    private volatile ServerSourceLine line;
    private volatile String initError = "Plasmo Voice is still starting (source line not created yet)";

    /** Call from DesechoPlugin#onLoad (Plasmo requires addons to be loaded in onLoad). */
    public static PlasmoVoiceBridge register() {
        PlasmoVoiceBridge b = new PlasmoVoiceBridge();
        PlasmoVoiceServer.getAddonsLoader().load(b);
        return b;
    }

    @Override public void onAddonInitialize() {
        try {
            line = voiceServer.getSourceLineManager().createBuilder(
                    this, "desecho", "DESECHO screens",
                    "plasmovoice:textures/icons/speaker_priority.png", 10).build();
            initError = null;
        } catch (Throwable t) {
            line = null;
            initError = "Plasmo Voice source line could not be created: " + t;
        }
    }

    @Override public void onAddonShutdown() {
        // Plasmo removes this addon's lines/sources on unload. DesechoPlugin closes its Outputs before that.
        line = null;
        initError = "Plasmo Voice addon was shut down";
    }

    @Override public boolean available() { return line != null; }
    @Override public String status() { return line != null ? "Plasmo Voice OK" : String.valueOf(initError); }

    @Override public Output open(String screenName, Location at, int rangeBlocks) {
        ServerSourceLine l = line;
        PlasmoVoiceServer server = voiceServer;
        if (l == null || server == null) throw new IllegalStateException(String.valueOf(initError));
        if (at.getWorld() == null) throw new IllegalStateException("Screen '" + screenName + "' has no world");
        String worldName = at.getWorld().getName();
        McServerWorld world = server.getMinecraftServer().getWorlds().stream()
                .filter(w -> w.getName().equals(worldName)).findAny()
                .orElseThrow(() -> new IllegalStateException("Plasmo Voice does not know world '" + worldName + "'"));
        short distance = (short) Math.max(1, Math.min(rangeBlocks, Short.MAX_VALUE));

        ServerPos3d pos = new ServerPos3d(world, at.getX(), at.getY(), at.getZ());
        ServerStaticSource source = l.createStaticSource(pos, false); // false = mono
        QueueAudioFrameProvider provider;
        try {
            provider = new QueueAudioFrameProvider(server, false); // false = mono (must match the source)
        } catch (RuntimeException | Error e) {
            try { source.remove(); } catch (Throwable ignored) { }
            throw e;
        }
        Handle h = new Handle(source, provider, distance);
        try {
            h.startSender();
        } catch (RuntimeException | Error e) {
            h.closeAll();
            throw e;
        }
        return h;
    }

    @Override public void shutdown() { /* nothing: Plasmo unloads the addon (and its sources) itself */ }

    /** The per-screen audio output. Thread-safe: accept() comes from the feeder thread, flush()/close() from the main/async threads. */
    private static final class Handle implements Output {
        private final ServerStaticSource source;
        private final QueueAudioFrameProvider provider;
        private final short distance;
        private final AtomicBoolean closed = new AtomicBoolean();
        private volatile AudioSender sender;
        private volatile boolean senderStopped;
        private volatile long lastCheckNanos;

        Handle(ServerStaticSource source, QueueAudioFrameProvider provider, short distance) {
            this.source = source; this.provider = provider; this.distance = distance;
        }

        synchronized void startSender() {
            if (closed.get()) return;
            AudioSender old = sender;
            if (old != null) { try { old.stop(); } catch (Throwable ignored) { } }
            AudioSender s = source.createAudioSender(provider, distance);
            sender = s;
            senderStopped = false;
            s.onStop(() -> {
                if (sender == s) senderStopped = true;
            });
            s.start();
            lastCheckNanos = System.nanoTime();
        }

        /**
         * At most twice a second, check the documented onStop callback state. If the queue becoming empty or another runtime
         * condition stops the sender coroutine, the next arriving PCM data restarts the sender with the same source/provider.
         */
        private void ensureSenderAlive() {
            long now = System.nanoTime();
            if (sender == null || !senderStopped || closed.get() || now - lastCheckNanos < 500_000_000L) return;
            lastCheckNanos = now;
            try { startSender(); } catch (RuntimeException ignored) { }
        }

        @Override public void accept(byte[] frame) {
            if (closed.get() || frame == null || frame.length < 2) return;
            short[] s = new short[frame.length / 2];
            ByteBuffer.wrap(frame, 0, s.length * 2).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(s);
            try {
                provider.addSamples(s);
            } catch (RuntimeException e) {
                if (closed.get()) return; // closed concurrently
                throw e;
            }
            ensureSenderAlive();
        }

        /** Pause / seek: drop queued-but-unsent audio. Sender, source and provider stay alive so playback can resume. */
        @Override public void flush() {
            if (closed.get()) return;
            try { provider.clear(); } catch (RuntimeException ignored) { }
        }

        @Override public void close() {
            if (!closed.compareAndSet(false, true)) return;
            closeAll();
        }

        /** Order matters: drop queued audio, stop the sender, then release the encoder, then remove the source. */
        synchronized void closeAll() {
            try { provider.clear(); } catch (Throwable ignored) { }
            AudioSender s = sender;
            if (s != null) { try { s.stop(); } catch (Throwable ignored) { } }
            sender = null;
            try { provider.close(); } catch (Throwable ignored) { }
            try { source.remove(); } catch (Throwable ignored) { }
        }
    }
}
