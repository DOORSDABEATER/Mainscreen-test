package dev.des.desecho.plugin;

import dev.des.desecho.core.display.PaletteQuantizer;
import dev.des.desecho.core.engine.AudioFeeder;
import dev.des.desecho.core.engine.ScreenPlayer;
import dev.des.desecho.core.media.FfmpegCommands;
import dev.des.desecho.core.media.QualityPreset;
import dev.des.desecho.core.permission.Actor;
import dev.des.desecho.core.playback.PlaybackSession;
import dev.des.desecho.core.playback.SessionManager;
import dev.des.desecho.core.playback.SessionState;
import dev.des.desecho.core.security.LocalMediaPolicy;
import dev.des.desecho.core.security.SecurityRejection;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.map.MapPalette;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

public final class DesechoPlugin extends JavaPlugin implements Listener {
    /** Everything that must be torn down together for one playing screen. */
    static final class Run {
        final PlaybackSession session; ScreenPlayer player; AudioFeeder feeder; VoiceBridge.Output audio;
        String audioNote = "";
        volatile String audioError; int lastEpoch;
        Run(PlaybackSession s) { this.session = s; }
    }

    final Map<String, Screen> screens = new ConcurrentHashMap<>();
    final Map<String, Run> runs = new ConcurrentHashMap<>();
    MapPool pool;
    ChunkTickets tickets;
    SessionManager mgr;
    PaletteQuantizer quantizer;
    LocalMediaPolicy media;
    VoiceBridge voice = VoiceBridge.unavailable("Voice not initialized");
    Path mediaDir;
    volatile boolean ffmpegOk;

    @Override public void onLoad() {
        // Plasmo Voice requires addons to be loaded in onLoad (official docs). plugin.yml has depend: [PlasmoVoice],
        // so PlasmoVoice is always loaded before this runs. Plasmo Voice is REQUIRED: if registration fails, onEnable disables us.
        try {
            voice = PlasmoVoiceBridge.register();
        } catch (Throwable t) {
            voice = VoiceBridge.unavailable("Plasmo Voice addon failed to register: " + t);
            getLogger().severe(voice.status());
        }
    }

    @Override public void onEnable() {
        if (!(voice instanceof PlasmoVoiceBridge)) {
            getLogger().severe("Plasmo Voice is required but the addon could not be registered in onLoad (" + voice.status()
                    + "). Disabling DESECHO.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        saveDefaultConfig();
        pool = new MapPool(getDataFolder());
        tickets = new ChunkTickets(this);
        mgr = new SessionManager(new SessionManager.Limits(getConfig().getInt("max-active-sessions", 4)), m -> getLogger().info("[audit] " + m));
        mediaDir = getDataFolder().toPath().resolve(getConfig().getString("media-dir", "media"));
        try {
            java.nio.file.Files.createDirectories(mediaDir);
            media = new LocalMediaPolicy(List.of(mediaDir), new HashSet<>(getConfig().getStringList("allowed-extensions")));
        } catch (IOException e) {
            getLogger().severe("Cannot create/read media dir " + mediaDir + ": " + e);
        }
        quantizer = buildQuantizer();
        checkFfmpegAsync();
        getLogger().info("Voice: " + voice.status() + " (source line is created when Plasmo Voice finishes starting)");

        DesechoCommand.register(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::tickPush, 1L, 1L);
        Bukkit.getScheduler().runTaskTimer(this, this::tickRanges, 10L, 10L);
        Bukkit.getScheduler().runTaskTimer(this, this::tickJanitor, 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, this::tickAudioSync, 2L, 2L);
        getLogger().info("DESECHO enabled. Media folder: " + mediaDir);
    }

    @Override public void onDisable() {
        // Audio outputs are closed (blocking) BEFORE the voice bridge is shut down.
        for (Run r : new ArrayList<>(runs.values())) closeRun(r, true);
        runs.clear();
        if (mgr != null) mgr.stopAll("plugin disable");
        for (Screen s : new ArrayList<>(screens.values())) s.destroy(pool);
        screens.clear();
        voice.shutdown();
    }

    @SuppressWarnings("deprecation")
    private PaletteQuantizer buildQuantizer() {
        int[] argb = new int[256];
        for (int i = 0; i < 256; i++) {
            try {
                java.awt.Color c = MapPalette.getColor((byte) i);
                argb[i] = (c.getAlpha() << 24) | (c.getRed() << 16) | (c.getGreen() << 8) | c.getBlue();
                // Defensive: as far as I recall, CraftMapView.render drops pixel bytes in [-128,-114] (indices 128..142) and leaves them
                // transparent. Never emit those indices. (Costs a few shades; VERIFY on the server: video must have no see-through speckles.)
                if (i >= 128 && i <= 142) argb[i] = 0;
            } catch (RuntimeException e) { argb[i] = 0; }
        }
        return new PaletteQuantizer(argb, 4);
    }

    private void checkFfmpegAsync() {
        String ff = getConfig().getString("ffmpeg-path", "ffmpeg");
        CompletableFuture.runAsync(() -> {
            try {
                Process p = new ProcessBuilder(ff, "-version").redirectErrorStream(true).start();
                p.getInputStream().readAllBytes();
                ffmpegOk = p.waitFor(10, TimeUnit.SECONDS) && p.exitValue() == 0;
            } catch (Exception e) { ffmpegOk = false; }
            if (ffmpegOk) getLogger().info("ffmpeg found (" + ff + ").");
            else getLogger().severe("ffmpeg NOT runnable at '" + ff + "'. Install it or set ffmpeg-path in config.yml. Playback will fail.");
        });
    }

    // ---------- ticks (main thread) ----------
    private void tickPush() { for (Screen s : screens.values()) s.push(); }

    private void tickRanges() {
        double vr = getConfig().getDouble("view-range", 48), ar = getConfig().getDouble("audio-range", 32);
        for (Screen s : screens.values()) {
            Set<UUID> v = new HashSet<>(), a = new HashSet<>();
            for (Player p : s.world.getPlayers()) {
                double d = p.getLocation().distanceSquared(s.center);
                if (d <= vr * vr) v.add(p.getUniqueId());
                if (d <= ar * ar) a.add(p.getUniqueId());
            }
            s.viewers = v; s.listeners = a;
        }
    }

    private void tickJanitor() {
        for (Map.Entry<String, Run> e : new ArrayList<>(runs.entrySet())) {
            Run r = e.getValue();
            var cur = mgr.get(e.getKey()).orElse(null);
            if (cur != r.session) { runs.remove(e.getKey(), r); closeRun(r, false); continue; }          // stopped/ended
            if (cur.state() == SessionState.FAILED) {
                tell(cur, "§cPlayback failed (" + cur.failureStage() + "): " + cur.failureMessage());
                mgr.forceStop(Actor.console(), e.getKey());
                runs.remove(e.getKey(), r); closeRun(r, false);
            }
            if (r.audioError != null) {
                tell(cur, "§eAudio problem: " + r.audioError);
                r.audioError = null;
            }
        }
    }

    /**
     * Pause / seek: drop queued audio promptly (every 2 ticks, not once a second) so old audio does not play after a seek and
     * new post-seek audio is not discarded by a late flush. The sender and source stay alive, so audio resumes on its own.
     */
    private void tickAudioSync() {
        for (Run r : runs.values()) {
            if (r.audio == null) continue;
            var cur = r.session;
            int epoch = cur.seekEpoch();
            if (cur.state() == SessionState.PAUSED || epoch != r.lastEpoch) {
                r.lastEpoch = epoch;
                r.audio.flush();
            }
        }
    }

    @EventHandler public void onFrameBreak(org.bukkit.event.hanging.HangingBreakEvent ev) {
        UUID id = ev.getEntity().getUniqueId();
        for (Screen s : screens.values()) if (!s.removed && s.ownsFrame(id)) { ev.setCancelled(true); return; }
    }

    @EventHandler public void onQuit(PlayerQuitEvent ev) { forgetViewer(ev.getPlayer().getUniqueId()); }

    /** The client may drop its map data on respawn / dimension change: forget what we sent so the next push resends everything. */
    @EventHandler public void onWorldChange(org.bukkit.event.player.PlayerChangedWorldEvent ev) { forgetViewer(ev.getPlayer().getUniqueId()); }
    @EventHandler public void onRespawn(org.bukkit.event.player.PlayerRespawnEvent ev) { forgetViewer(ev.getPlayer().getUniqueId()); }

    private void forgetViewer(UUID id) { for (Screen s : screens.values()) s.lastSent.remove(id); }

    // ---------- operations used by commands ----------
    void tell(PlaybackSession s, String msg) {
        Player p = Bukkit.getPlayer(s.ownerId());
        if (p != null) p.sendMessage(msg); else getLogger().info(org.bukkit.ChatColor.stripColor(msg));
    }

    Actor actor(CommandSender s) {
        if (!(s instanceof Player p)) return Actor.console();
        return new Actor(p.getUniqueId(), p.getName(), p.hasPermission("desecho.play"), p.hasPermission("desecho.display.manage"),
                p.isOp() || p.hasPermission("desecho.admin"));
    }

    /** @return message lines for the sender */
    List<String> play(CommandSender sender, Screen screen, String fileArg) {
        List<String> out = new ArrayList<>();
        if (!ffmpegOk) { out.add("§cffmpeg is not available (see server log)."); return out; }
        if (media == null) { out.add("§cMedia folder is not usable (see server log)."); return out; }
        Path file;
        try { file = media.resolve(fileArg); } catch (SecurityRejection e) { out.add("§c" + e.getMessage()); return out; }
        boolean audioOk = voice.available();
        if (!audioOk && getConfig().getBoolean("require-audio", false)) {
            out.add("§cAudio backend unavailable and require-audio=true: " + voice.status()); return out;
        }
        if (runs.containsKey(screen.name)) { out.add("§cThat screen is already playing."); return out; }
        var res = mgr.play(actor(sender), screen.name, "file:" + fileArg);
        if (!res.ok()) { out.add("§c" + res.message()); return out; }
        PlaybackSession session = res.session();
        Run run = new Run(session);
        try {
            var src = new FfmpegCommands.Source(file.toString(), true);
            String ff = getConfig().getString("ffmpeg-path", "ffmpeg");
            int maxSec = getConfig().getInt("max-seconds", 14400);
            long grace = getConfig().getLong("idle-grace-ms", 5000);
            QualityPreset q = QualityPreset.valueOf(getConfig().getString("quality", "ECONOMY").toUpperCase());
            var plan = q.plan(screen.width(), screen.height(), getConfig().getInt("max-fps", 10));
            var cfg = new ScreenPlayer.Config(ff, screen.width(), screen.height(), plan, maxSec, getConfig().getInt("queue-capacity", 30), grace);
            run.player = new ScreenPlayer(mgr, session, src, cfg, quantizer, screen, () -> !screen.viewers.isEmpty());

            if (audioOk) {
                try {
                    run.audio = voice.open(screen.name, screen.center, getConfig().getInt("audio-range", 32));
                } catch (RuntimeException e) {
                    run.audioNote = "audio output could not be opened: " + e.getMessage();
                }
            } else run.audioNote = voice.status();
            if (run.audio == null && getConfig().getBoolean("require-audio", false)) {
                mgr.forceStop(Actor.console(), screen.name);
                closeRun(run, false);
                out.add("§cAudio could not be started and require-audio=true: " + run.audioNote);
                return out;
            }
            if (run.audio != null) {
                final VoiceBridge.Output audio = run.audio;
                run.feeder = new AudioFeeder(mgr, session, src, ff, maxSec, grace,
                        frame -> { applyGain(frame, session.muted() ? 0 : session.volume()); audio.accept(frame); },
                        () -> !screen.listeners.isEmpty(),
                        msg -> run.audioError = msg);
            }
            runs.put(screen.name, run);
            run.player.start();
            if (run.feeder != null) run.feeder.start();
        } catch (RuntimeException e) {
            mgr.forceStop(Actor.console(), screen.name);
            closeRun(run, false);
            out.add("§cCould not start playback: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            return out;
        }
        out.add("§aLoading " + fileArg + " on '" + screen.name + "'...");
        if (run.audio == null) out.add("§eNO AUDIO: " + run.audioNote);
        else out.add("§7Audio via Plasmo Voice, range " + getConfig().getInt("audio-range", 32) + " blocks. Players need the Plasmo Voice mod installed and connected.");
        return out;
    }

    /** Stop everything belonging to a screen (after the session was already removed from the manager). */
    void endRun(String screenName) {
        Run r = runs.remove(screenName);
        if (r != null) closeRun(r, false);
    }

    void removeScreen(String name) {
        Screen s = screens.remove(name);
        if (s == null) return;
        endRun(name);
        s.destroy(pool);
    }

    /** Never blocks the main thread except on disable. */
    void closeRun(Run r, boolean blocking) {
        Runnable job = () -> {
            if (r.feeder != null) r.feeder.close();
            if (r.player != null) r.player.close();
            if (r.audio != null) r.audio.close();
        };
        if (blocking) job.run(); else CompletableFuture.runAsync(job);
    }

    static void applyGain(byte[] frame, int vol) {
        if (vol >= 100) return;
        ByteBuffer b = ByteBuffer.wrap(frame).order(ByteOrder.LITTLE_ENDIAN);
        for (int i = 0; i + 1 < frame.length; i += 2) b.putShort(i, (short) (b.getShort(i) * vol / 100));
    }

    File mediaFolder() { return mediaDir.toFile(); }
}
