plugins {
    `java-library`
    id("com.gradleup.shadow") version "9.0.0"
}

java { toolchain { languageVersion = JavaLanguageVersion.of(25) } }

repositories {
    maven("https://repo.papermc.io/repository/maven-public/")
    maven("https://repo.plasmoverse.com/releases")
}

val paperApiVersion: String by project
val plasmoVoiceApiVersion: String by project

dependencies {
    compileOnly("io.papermc.paper:paper-api:$paperApiVersion")
    // Plasmo Voice is REQUIRED at runtime (plugin.yml `depend: [PlasmoVoice]`). Compile-only: provided by the server, never shaded.
    compileOnly("su.plo.voice.api:server:$plasmoVoiceApiVersion")
    implementation(project(":core"))
}

tasks.shadowJar {
    archiveBaseName = "DESECHO"
    archiveClassifier = ""
    archiveVersion = ""
    // result: plugin/build/libs/DESECHO.jar  (core is bundled inside)
}
tasks.build { dependsOn(tasks.shadowJar) }
