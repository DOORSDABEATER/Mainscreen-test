rootProject.name = "desecho"
include("core", "plugin")
